﻿using ModuleBOARD.Elements.Base;
using ModuleBOARD.Elements.Lots;
using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BoardSpace
{
    public partial class BoardPanel : UserControl
    {
        public GeoVue GV;
        public Groupe root;
        public Size textureTaille;
        public Image[] textureDuBoard;
        public Joueur joueur;
        public Dictionary<ushort, Joueur> DicoJoueurs;

        public BoardPanel()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.AllowDrop = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (root != null)
            {
                //Redessiner(e.Graphics);
                Graphics g = e.Graphics;
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighSpeed;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Low;
                g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
                RectangleF vue = new RectangleF(GV.GC.P.X, GV.GC.P.Y, this.Width / GV.GC.E, this.Height / GV.GC.E);
                g.TranslateTransform(GV.DimentionD2.X, GV.DimentionD2.Y);
                g.RotateTransform(GV.GC.A);
                g.ScaleTransform(GV.GC.E, GV.GC.E);
                g.TranslateTransform(-GV.GC.P.X, -GV.GC.P.Y);

                if (textureDuBoard != null)
                {
                    float f = (vue.X + vue.Width) / textureTaille.Width;
                    int basX = (int)f;
                    if (f - basX > 0.0000001f) ++basX;
                    //++basX;
                    f = (vue.Y + vue.Height) / textureTaille.Height;
                    int basY = (int)f;
                    if (f - basY > 0.0000001f) ++basY;
                    //++basY;

                    f = (vue.X - vue.Width) / textureTaille.Width;
                    int hautX = (int)f;
                    if (f - hautX < -0.0000001f) --hautX;
                    //--hautX;
                    f = (vue.Y - vue.Height) / textureTaille.Height;
                    int hautY = (int)f;
                    if (f - hautY < -0.0000001f) --hautY;

                    int select;
                    if (GV.GC.E >= 1.0f) select = (int)((6.0f - GV.GC.E) / 3.0f); // (6 - e)/3
                    else select = (int)(4 - (6.0f - (1.0f / GV.GC.E)) / 2.5f); //4-(6-(1/e))/3
                    if (select < 0) select = 0; else if (select >= textureDuBoard.Length) select = textureDuBoard.Length - 1;
                    Image hitmap = textureDuBoard[select];

                    int dlt = 6 + (int)(0.6f / GV.GC.E);
                    for (int y = hautY; y < basY; ++y)
                    {
                        for (int x = hautX; x < basX; ++x)
                        {
                            g.DrawImage(hitmap, x * textureTaille.Width - dlt, y * textureTaille.Height - dlt, textureTaille.Width + 2 * dlt, textureTaille.Height + 2 * dlt);
                        }
                    }
                }
                root.Dessiner(joueur?.IdSessionJoueur ?? 0, vue, GV.GC.A, g);

                if (DicoJoueurs != null)
                    foreach (var kv in DicoJoueurs) if (kv.Value != null)
                            kv.Value.Dessiner(false, joueur?.IdSessionJoueur ?? 0, vue, GV.GC.A, g);
                if (joueur != null) joueur.Dessiner(true, joueur?.IdSessionJoueur ?? 0, vue, GV.GC.A, g);
            }
        }
    }
}
