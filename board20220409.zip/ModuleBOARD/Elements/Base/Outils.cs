﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base
{
    static public class Outils
    {
        static public Rectangle Rect(this Image img) { return new Rectangle(0, 0, img.Width, img.Height); }
        static public RectangleF RectF(this Image img) { return new RectangleF(0, 0, img.Width, img.Height); }

        static public Matrix Dessiner(this Image img, RectangleF vue, Graphics g, GeoCoord2D GC, RectangleF dRect)
        {
            Matrix res;
            /*g.ResetTransform();
            g.RotateTransform(10.0f);*/

            if (img != null)
            {
                float sclRatio = GC.E / Math.Min(img.Width, img.Height);
                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                g.DrawImage(img, dRect);
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = null;

            return res;
        }

        static public Matrix Dessiner(this Image img, RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            /*g.ResetTransform();
            g.RotateTransform(10.0f);*/

            if (img != null)
            {
                float sclRatio = GC.E / Math.Min(img.Width, img.Height);
                RectangleF dRect = new RectangleF(-img.Width / 2, -img.Height / 2, img.Width, img.Height);

                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                g.DrawImage(img, dRect);
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = null;

            return res;
        }

        static public Matrix DessinerVide(this Image img, RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            if (img.Width > 0 && img.Height > 0)
            {
                float sclRatio = Math.Min(img.Width, img.Height);
                RectangleF dRect = new RectangleF(-img.Width / 2, -img.Height / 2, img.Width, img.Height);

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = null;
            return res;
        }

        static public Matrix DessinerVide(this Point img, RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            if (img.X > 0 && img.Y > 0)
            {
                float sclRatio = Math.Min(img.X, img.Y);
                RectangleF dRect = new RectangleF(-img.X / 2, -img.Y / 2, img.X, img.Y);

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = null;
            return res;
        }

        static public Matrix DessinerVide(this RectangleF dRect, RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            if (dRect.Width > 0 && dRect.Height > 0)
            {
                float sclRatio = Math.Min(dRect.Width, dRect.Height);
                if (sclRatio < 0.0f) sclRatio = -sclRatio;

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = null;
            return res;
        }

        /*
        //Les attributs de nsrc sont recoppié partout dans nfus si ils n'existe pas déjà.
        static public XmlNode FusionAttributs(this XmlNode nfus, XmlNode nsrc)
        {
            return nfus;
        }
        */

        static public XmlNode Renomer(this XmlNode rnm, string nname)
        {
            XmlNode nn = rnm.OwnerDocument.CreateNode(rnm.NodeType, "nname", rnm.NamespaceURI);
            foreach (XmlAttribute att in rnm.Attributes)
            {
                    nn.Attributes.Append(att);
            }
            foreach (XmlNode chld in rnm.ChildNodes)
            {
                nn.AppendChild(chld);
            }
            return nn;
        }

        //Les attributs de l'arbre nsrc sont remappé dans l'arbre nfus si ils n'existent pas déjà.
        static public void FusionArbreAttributs(this XmlNode nfus, XmlNode nsrc)
        {
            foreach(XmlAttribute att in nsrc.Attributes)
            {
                if(nfus.Attributes.GetNamedItem(att.Name) == null)
                    nfus.Attributes.Append((XmlAttribute)att.Clone());
            }

            int isrc;
            for (isrc = 0; isrc < nsrc.ChildNodes.Count && nsrc.ChildNodes[isrc].Name.StartsWith("+"); ++isrc)
            {
                nfus.PrependChild(nsrc.ChildNodes[isrc].Renomer(nsrc.ChildNodes[isrc].Name.Substring(1)));
            }
            for (int ifus = 0; ifus < nfus.ChildNodes.Count; ++ifus)
            {
                XmlNode n = nfus.ChildNodes[ifus];
                string nmfus = n.Name.ToLower();
                if (nmfus.StartsWith("+"))
                {
                    XmlNode nn = n.Renomer(n.Name.Substring(1));
                    nfus.ReplaceChild(nn, n);
                }
                else
                {
                    int jsrc;
                    for (jsrc = isrc; jsrc < nsrc.ChildNodes.Count && !String.Equals(nmfus, nsrc.ChildNodes[isrc].Name.ToLower()); ++jsrc);
                    if(jsrc < nsrc.ChildNodes.Count)
                    {
                        for (; isrc < jsrc; ++isrc)
                        {
                            if(nsrc.ChildNodes[isrc].Name.StartsWith("+"))
                                nfus.InsertBefore(nsrc.ChildNodes[isrc].Renomer(nsrc.ChildNodes[isrc].Name.Substring(1)), n);
                        }
                        n.FusionArbreAttributs(nsrc.ChildNodes[jsrc]);
                        isrc = jsrc + 1;
                    }
                }
            }
            for (; isrc < nsrc.ChildNodes.Count; ++isrc)
            {
                if (nsrc.ChildNodes[isrc].Name.StartsWith("+"))
                    nfus.AppendChild(nsrc.ChildNodes[isrc].Renomer(nsrc.ChildNodes[isrc].Name.Substring(1)));
            }
        }
    }
}
