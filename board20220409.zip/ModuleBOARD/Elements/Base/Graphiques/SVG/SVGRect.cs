﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base.Graphiques.SVG
{
    public class SVGRect : Graphique
    {
        private RectangleF rect;
        private Color contour;
        private Color remplissage;
        private float épaisseur;

        override public GType GraphType { get => GType.rect; }

        public override Size Size => new Size((int)(2 * Math.Max(Math.Abs(rect.X), Math.Abs(rect.X + rect.Width))), (int)(2 * Math.Max(Math.Abs(rect.Y), Math.Abs(rect.Y + rect.Height))));

        public override SizeF SizeF => new SizeF(2.0f * Math.Max(Math.Abs(rect.X), Math.Abs(rect.X + rect.Width)), 2.0f * Math.Max(Math.Abs(rect.Y), Math.Abs(rect.Y + rect.Height)));

        public override (PointF, PointF) MinMax { get => (new PointF(rect.X, rect.Y), new PointF(rect.X + rect.Width, rect.Y + rect.Height)); }

        public SVGRect()
        {
        }

        public SVGRect(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
        {
            //<line x1="5" y1="5" x2="250" y2="95" stroke="red" />
            rect = new RectangleF
            (
                float.Parse(paq.Attributes.GetNamedItem("x").Value), float.Parse(paq.Attributes.GetNamedItem("y").Value),
                float.Parse(paq.Attributes.GetNamedItem("width").Value), float.Parse(paq.Attributes.GetNamedItem("height").Value)
            );
            contour = Color.FromName(paq.Attributes.GetNamedItem("stroke")?.Value ?? "Transparent");
            remplissage = Color.FromName(paq.Attributes.GetNamedItem("fill")?.Value ?? "Transparent");
            épaisseur = float.Parse(paq.Attributes.GetNamedItem("stroke-width")?.Value ?? "1");

            float contourOpacité = float.Parse(paq.Attributes.GetNamedItem("stroke-opacity")?.Value ?? "1");
            if (contourOpacité < 1.0f) contour = Color.FromArgb((byte)(255.0 * contourOpacité + 0.5f), contour);
            float remplissageOpacité = float.Parse(paq.Attributes.GetNamedItem("fill-opacity")?.Value ?? "1");
            if (remplissageOpacité < 1.0f) remplissage = Color.FromArgb((byte)(255.0 * remplissageOpacité + 0.5f), remplissage);
        }

        public override void Centrer(PointF ctr)
        {
            rect.X -= ctr.X;
            rect.Y -= ctr.Y;
        }

        public override void Dessiner(Graphics g, bool Retournée)
        {
            Pen pn = new Pen(contour, épaisseur);
            if (Retournée)
            {
                Matrix m = g.Transform;
                g.ScaleTransform(-1.0f, 1.0f);
                if (contour != Color.Transparent && épaisseur > 0.0f) g.DrawRectangle(new Pen(contour, épaisseur), rect.X, rect.Y, rect.Width, rect.Height);
                if(remplissage != Color.Transparent) g.FillRectangle(new SolidBrush(remplissage), rect);
                g.Transform = m;
            }
            else
            {
                if (contour != Color.Transparent && épaisseur > 0.0f) g.DrawRectangle(new Pen(contour, épaisseur), rect.X, rect.Y, rect.Width, rect.Height);
                if(remplissage != Color.Transparent) g.FillRectangle(new SolidBrush(remplissage), rect);
            }
        }

        public override void MettreAJour(object obj) { }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(contour);
            stream.SerialiserObject(remplissage);
            stream.SerialiserObject(épaisseur);
            stream.SerialiserObject(rect);
        }

        public SVGRect(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            contour = (Color)stream.DésérialiserObject(typeof(Color));
            remplissage = (Color)stream.DésérialiserObject(typeof(Color));
            épaisseur = (float)stream.DésérialiserObject(typeof(float));
            rect = (RectangleF)stream.DésérialiserObject(typeof(RectangleF));
        }
    }
}
