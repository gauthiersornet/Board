﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base.Graphiques.SVG
{
    public class SVGText : Graphique
    {
        /*[Flags]
        private enum ECentrer : byte
        {
            Centre = 0,
            Gauche = (1 << 0),
            Droite = (1 << 1),
            Haut = (1 << 2),
            Bas = (1 << 3),
        }*/

        private PointF pt;
        private string texte;
        private Color couleur;
        private Font font;
        private SizeF taille;
        //private ECentrer centrer;
        private float angle;

        override public GType GraphType { get => GType.text; }

        public SizeF EstimerTaille { get
            {
                if (texte != null && font != null)
                {
                    string[] lns = texte.Replace("\r", "").Split('\n');
                    return new SizeF((lns.Max(l => l.Length) * 0.88f + (3.6f / 20)) * font.Size  , (lns.Length * 1.2f + (6.8f / 20)) * font.Size);
                }
                else return new SizeF(0.0f, 0.0f);
            }
        }

        public override Size Size { get
            {
                SizeF esti = taille;
                return new Size((int)(2 * Math.Max(Math.Abs(pt.X), Math.Abs(pt.X + esti.Width))), (int)(2 * Math.Max(Math.Abs(pt.Y), Math.Abs(pt.Y + esti.Height))));
            }
        }

        public override SizeF SizeF { get
            {
                SizeF esti = taille;
                return new SizeF((2 * Math.Max(Math.Abs(pt.X), Math.Abs(pt.X + esti.Width))), (2 * Math.Max(Math.Abs(pt.Y), Math.Abs(pt.Y + esti.Height))));
            }
        }

        public override (PointF, PointF) MinMax { get
            {
                if(angle == 0.0f)return (pt, new PointF(pt.X + taille.Width, pt.Y + taille.Height));
                else
                {
                    Matrix m = new Matrix();
                    m.Rotate(-angle);
                    PointF rp = new PointF
                        (
                            pt.X * m.Elements[0] + pt.Y * m.Elements[1],
                            pt.X * m.Elements[2] + pt.Y * m.Elements[3]
                        );
                    PointF vecX = new PointF
                        (
                            taille.Width * m.Elements[0],
                            taille.Width * m.Elements[2]
                        );
                    PointF vecY = new PointF
                        (
                            taille.Height * m.Elements[1],
                            taille.Height * m.Elements[3]
                        );
                    PointF min = rp;
                    PointF max = rp;
                    PointF v = new PointF(rp.X + vecX.X, rp.Y + vecX.Y);
                    min.X = Math.Min(min.X, v.X); max.X = Math.Max(max.X, v.X);
                    min.Y = Math.Min(min.Y, v.Y); max.Y = Math.Max(max.Y, v.Y);
                    v = new PointF(v.X + vecY.X, v.Y + vecY.Y);
                    min.X = Math.Min(min.X, v.X); max.X = Math.Max(max.X, v.X);
                    min.Y = Math.Min(min.Y, v.Y); max.Y = Math.Max(max.Y, v.Y);
                    v = new PointF(rp.X + vecY.X, rp.Y + vecY.Y);
                    min.X = Math.Min(min.X, v.X); max.X = Math.Max(max.X, v.X);
                    min.Y = Math.Min(min.Y, v.Y); max.Y = Math.Max(max.Y, v.Y);
                    return (min, max);
                }
            } }

        public SVGText()
        {
            texte = "";
            font = new Font(FontFamily.GenericSansSerif, 1.0f);
        }

        public SVGText(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
        {
            //<text x="180" y="60">Un texte</text>
            pt = new PointF(float.Parse(paq.Attributes.GetNamedItem("cx")?.Value ?? "0"), float.Parse(paq.Attributes.GetNamedItem("cy")?.Value ?? "0"));
            texte = paq.InnerText;
            couleur = Color.FromName(paq.Attributes.GetNamedItem("stroke")?.Value ?? "Black");
            string sépaisseur = paq.Attributes.GetNamedItem("font-size")?.Value?.Trim() ?? "20";
            if (sépaisseur.EndsWith("pt")) sépaisseur = sépaisseur.Substring(0, sépaisseur.Length - 2);
            float épaisseur = float.Parse(sépaisseur);
            string sFontStyle = paq.Attributes.GetNamedItem("font-style")?.Value;
            FontStyle fStl;
            if (sFontStyle != null && Enum.IsDefined(typeof(FontStyle), sFontStyle))
                fStl = (FontStyle)Enum.Parse(typeof(FontStyle), sFontStyle);
            else fStl = FontStyle.Regular;
            string sfontFamilly = paq.Attributes.GetNamedItem("font-family")?.Value;
            if (!string.IsNullOrWhiteSpace(sfontFamilly))
            {
                try
                {
                    font = new Font(sfontFamilly, épaisseur, fStl);
                }
                catch { font = new Font(FontFamily.GenericMonospace, épaisseur, fStl); }
            }
            else font = new Font(FontFamily.GenericMonospace, épaisseur, fStl);

            float couleurOpacité = float.Parse(paq.Attributes.GetNamedItem("stroke-opacity")?.Value ?? "1");
            if (couleurOpacité < 1.0f) couleur = Color.FromArgb((byte)(255.0 * couleurOpacité + 0.5f), couleur);

            taille = EstimerTaille;
            PointF vec = new PointF(-taille.Width / 2.0f, -taille.Height / 2.0f);
            //centrer = ECentrer.Centre;

            string strCentrer = paq.Attributes.GetNamedItem("center")?.Value?.Trim().ToLower() ?? "";
            if (strCentrer.Contains("left"))
            {
                //centrer |= ECentrer.Gauche;
                vec.X += taille.Width / 2.0f;
            }
            if (strCentrer.Contains("right"))
            {
                //centrer |= ECentrer.Droite;
                vec.X -= taille.Width / 2.0f;
            }
            if (strCentrer.Contains("top") || strCentrer.Contains("up"))
            {
                //centrer |= ECentrer.Haut;
                vec.Y += taille.Height / 2.0f;
            }
            if (strCentrer.Contains("bottom") || strCentrer.Contains("down"))
            {
                //centrer |= ECentrer.Bas;
                vec.Y -= taille.Height / 2.0f;
            }

            angle = float.Parse(paq.Attributes.GetNamedItem("rotation")?.Value ?? "0");
            if (angle != 0.0f)
            {
                Matrix m = new Matrix();
                m.Rotate(angle);
                pt = new PointF
                    (
                        pt.X * m.Elements[0] + pt.Y * m.Elements[1],
                        pt.X * m.Elements[2] + pt.Y * m.Elements[3]
                    );
            }

            pt.X += vec.X;
            pt.Y += vec.Y;
        }

        public override void Centrer(PointF ctr)
        {
            pt.X -= ctr.X;
            pt.Y -= ctr.Y;
        }

        public override void Dessiner(Graphics g, bool Retournée)
        {
            if (!string.IsNullOrWhiteSpace(texte) && font != null)
            {
                Matrix m = g.Transform;
                if (Retournée) g.ScaleTransform(-1.0f, 1.0f);
                if (angle != 0.0f) g.RotateTransform(angle);
                g.DrawString(texte, font, new SolidBrush(couleur), pt.X, pt.Y);
                g.Transform = m;
            }
        }

        public override void MettreAJour(object obj) { }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(couleur);
            stream.SerialiserObject(font.FontFamily.Name);
            stream.SerialiserObject(font.Style);
            stream.SerialiserObject(font.Size);
            stream.SerialiserObject(pt);
            stream.SerialiserObject(angle);
            stream.SerialiserObject(taille);
            stream.SerialiserObject(texte);
        }

        public SVGText(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            couleur = (Color)stream.DésérialiserObject(typeof(Color));
            string sfont = (string)stream.DésérialiserObject(typeof(string));
            FontStyle fstl = (FontStyle)stream.DésérialiserObject(typeof(FontStyle));
            float épaisseur = (float)stream.DésérialiserObject(typeof(float));
            try
            {
                font = new Font(sfont, épaisseur, fstl);
            }
            catch
            {
                font = new Font(FontFamily.GenericMonospace, épaisseur);
            }
            pt = (PointF)stream.DésérialiserObject(typeof(PointF));
            angle = (float)stream.DésérialiserObject(typeof(float));
            taille = (SizeF)stream.DésérialiserObject(typeof(SizeF));
            texte = (string)stream.DésérialiserObject(typeof(string));
        }
    }
}
