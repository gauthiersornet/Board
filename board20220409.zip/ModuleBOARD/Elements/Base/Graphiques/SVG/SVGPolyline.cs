﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base.Graphiques.SVG
{
    public class SVGPolyline : Graphique
    {
        private PointF[] pts;
        private Color contour;
        private float épaisseur;

        override public GType GraphType { get => GType.polyline; }

        public override Size Size => new Size((int)(2*pts.Max(p => Math.Abs(p.X))), (int)(2*pts.Max(p => Math.Abs(p.Y))));

        public override SizeF SizeF => new SizeF(2.0f * pts.Max(p => Math.Abs(p.X)), 2.0f * pts.Max(p => Math.Abs(p.Y)));

        public override (PointF, PointF) MinMax { get
            {
                if (pts.Any())
                {
                    PointF min = new PointF(float.MaxValue, float.MaxValue);
                    PointF max = new PointF(float.MinValue, float.MinValue);
                    foreach(PointF p in pts)
                    {
                        min.X = Math.Min(min.X, p.X);
                        min.Y = Math.Min(min.Y, p.Y);
                        max.X = Math.Max(max.X, p.X);
                        max.Y = Math.Max(max.Y, p.Y);
                    }
                    return (min, max);
                }
                else return (new PointF(), new PointF());
            } }

        public SVGPolyline()
        {
        }

        public SVGPolyline(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
        {
            //<polyline points="60 110 65 120 70 115 75 130 80 125 85 140 90 135 95 150 100 145" stroke="orange" fill="transparent" stroke-width="5"/>
            contour = Color.FromName(paq.Attributes.GetNamedItem("stroke")?.Value ?? "Black");
            épaisseur = float.Parse(paq.Attributes.GetNamedItem("stroke-width")?.Value ?? "1");
            string[] spts = paq.Attributes.GetNamedItem("points").Value.Replace("  ", " ").Trim().Split(' ');
            pts = new PointF[spts.Length / 2];
            for(int i = 0; i < pts.Length; ++i) pts[i] = new PointF(float.Parse(spts[2 * i]), float.Parse(spts[2 * i + 1]));

            float contourOpacité = float.Parse(paq.Attributes.GetNamedItem("stroke-opacity")?.Value ?? "1");
            if (contourOpacité < 1.0f) contour = Color.FromArgb((byte)(255.0 * contourOpacité + 0.5f), contour);
        }

        public override void Centrer(PointF ctr)
        {
            if(pts != null) for(int i = 0; i < pts.Length; ++i)
                {
                    pts[i].X -= ctr.X;
                    pts[i].Y -= ctr.Y;
                }
        }

        public override void Dessiner(Graphics g, bool Retournée)
        {
            Pen pn = new Pen(contour, épaisseur);
            if (Retournée)
            {
                Matrix m = g.Transform;
                g.ScaleTransform(-1.0f, 1.0f);
                g.DrawLines(pn, pts);
                g.Transform = m;
            }
            else g.DrawLines(pn, pts);
        }

        public override void MettreAJour(object obj) { }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);   
            stream.SerialiserObject(contour);
            stream.SerialiserObject(épaisseur);
            stream.SerialiserObject(pts);
        }

        public SVGPolyline(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            contour = (Color)stream.DésérialiserObject(typeof(Color));
            épaisseur = (float)stream.DésérialiserObject(typeof(float));
            pts = (PointF[])stream.DésérialiserObject(typeof(PointF[]));
        }
    }
}
