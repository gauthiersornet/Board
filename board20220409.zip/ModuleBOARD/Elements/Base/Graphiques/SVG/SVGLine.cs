﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base.Graphiques.SVG
{
    public class SVGLine : Graphique
    {
        private PointF pt1, pt2;
        private Color contour;
        private float épaisseur;

        override public GType GraphType { get => GType.line; }

        public override Size Size => new Size((int)(2 * Math.Max(Math.Abs(pt1.X), Math.Abs(pt2.X))), (int)(2 * Math.Max(Math.Abs(pt1.Y), Math.Abs(pt2.Y))));

        public override SizeF SizeF => new SizeF(2.0f * Math.Max(Math.Abs(pt1.X), Math.Abs(pt2.X)), 2.0f * Math.Max(Math.Abs(pt1.Y), Math.Abs(pt2.Y)));

        public override(PointF, PointF) MinMax { get => (new PointF(Math.Min(pt1.X, pt2.X), Math.Min(pt1.Y, pt2.Y)), new PointF(Math.Max(pt1.X, pt2.X), Math.Max(pt1.Y, pt2.Y))); }

        public SVGLine()
        { 
        }

        public SVGLine(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
        {
            //<line x1="5" y1="5" x2="250" y2="95" stroke="red" />
            pt1 = new PointF(float.Parse(paq.Attributes.GetNamedItem("x1").Value), float.Parse(paq.Attributes.GetNamedItem("y1").Value));
            pt2 = new PointF(float.Parse(paq.Attributes.GetNamedItem("x2").Value), float.Parse(paq.Attributes.GetNamedItem("y2").Value));
            contour = Color.FromName(paq.Attributes.GetNamedItem("stroke")?.Value ?? "Black");
            épaisseur = float.Parse(paq.Attributes.GetNamedItem("stroke-width")?.Value ?? "1");

            float contourOpacité = float.Parse(paq.Attributes.GetNamedItem("stroke-opacity")?.Value ?? "1");
            if (contourOpacité < 1.0f) contour = Color.FromArgb((byte)(255.0 * contourOpacité + 0.5f), contour);
        }

        public override void Centrer(PointF ctr)
        {
            pt1.X -= ctr.X;
            pt1.Y -= ctr.Y;
            pt2.X -= ctr.X;
            pt2.Y -= ctr.Y;
        }

        public override void Dessiner(Graphics g, bool Retournée)
        {
            Pen pn = new Pen(contour, épaisseur);
            if (Retournée)
            {
                Matrix m = g.Transform;
                g.ScaleTransform(-1.0f, 1.0f);
                g.DrawLine(pn, pt1, pt2);
                g.Transform = m;
            }
            else g.DrawLine(pn, pt1, pt2);
        }

        public override void MettreAJour(object obj){}

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(contour);
            stream.SerialiserObject(épaisseur);
            stream.SerialiserObject(pt1);
            stream.SerialiserObject(pt2);
        }

        public SVGLine(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            contour = (Color)stream.DésérialiserObject(typeof(Color));
            épaisseur = (float)stream.DésérialiserObject(typeof(float));
            pt1 = (PointF)stream.DésérialiserObject(typeof(PointF));
            pt2 = (PointF)stream.DésérialiserObject(typeof(PointF));
        }
    }
}
