﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base.Graphiques.SVG
{
    public class SVGCicrle : Graphique
    {
        private PointF pt;
        private float rayon;
        private Color contour;
        private Color remplissage;
        private float épaisseur;

        override public GType GraphType { get => GType.circle; }

        public override Size Size => new Size((int)(2 * Math.Max(Math.Abs(pt.X - rayon), Math.Abs(pt.X + rayon))), (int)(2 * Math.Max(Math.Abs(pt.Y - rayon), Math.Abs(pt.Y + rayon))));

        public override SizeF SizeF => new SizeF(2.0f * Math.Max(Math.Abs(pt.X - rayon), Math.Abs(pt.X + rayon)), 2.0f * Math.Max(Math.Abs(pt.Y - rayon), Math.Abs(pt.Y + rayon)));

        public override (PointF, PointF) MinMax { get => (new PointF(-rayon, -rayon), new PointF(rayon, rayon)); }

        public SVGCicrle()
        {
        }

        public SVGCicrle(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
        {
            //<circle cx="25" cy="75" r="20"/>
            pt = new PointF(float.Parse(paq.Attributes.GetNamedItem("cx")?.Value ?? "0"), float.Parse(paq.Attributes.GetNamedItem("cy")?.Value ?? "0"));
            rayon = float.Parse(paq.Attributes.GetNamedItem("r").Value);
            contour = Color.FromName(paq.Attributes.GetNamedItem("stroke")?.Value ?? "Transparent");
            remplissage = Color.FromName(paq.Attributes.GetNamedItem("fill")?.Value ?? "Transparent");
            épaisseur = float.Parse(paq.Attributes.GetNamedItem("stroke-width")?.Value ?? "1");

            float contourOpacité = float.Parse(paq.Attributes.GetNamedItem("stroke-opacity")?.Value ?? "1");
            if (contourOpacité < 1.0f) contour = Color.FromArgb((byte)(255.0 * contourOpacité + 0.5f), contour);
            float remplissageOpacité = float.Parse(paq.Attributes.GetNamedItem("fill-opacity")?.Value ?? "1");
            if (remplissageOpacité < 1.0f) remplissage = Color.FromArgb((byte)(255.0 * remplissageOpacité + 0.5f), remplissage);
        }

        public override void Centrer(PointF ctr)
        {
            pt.X -= ctr.X;
            pt.Y -= ctr.Y;
        }

        public override void Dessiner(Graphics g, bool Retournée)
        {
            if (Retournée)
            {
                Matrix m = g.Transform;
                g.ScaleTransform(-1.0f, 1.0f);
                if (remplissage != Color.Transparent) g.FillEllipse(new SolidBrush(remplissage), pt.X - rayon, pt.Y - rayon, rayon * 2, rayon * 2);
                if (contour != Color.Transparent && épaisseur > 0.0f) g.DrawEllipse(new Pen(contour, épaisseur), pt.X - rayon, pt.Y - rayon, rayon * 2, rayon * 2);
                g.Transform = m;
            }
            else
            {
                if (remplissage != Color.Transparent) g.FillEllipse(new SolidBrush(remplissage), pt.X - rayon, pt.Y - rayon, rayon * 2, rayon * 2);
                if (contour != Color.Transparent && épaisseur > 0.0f) g.DrawEllipse(new Pen(contour, épaisseur), pt.X - rayon, pt.Y - rayon, rayon * 2, rayon * 2);
            }
        }

        public override void MettreAJour(object obj) { }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(contour);
            stream.SerialiserObject(remplissage);
            stream.SerialiserObject(épaisseur);
            stream.SerialiserObject(pt);
            stream.SerialiserObject(rayon);
        }

        public SVGCicrle(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            contour = (Color)stream.DésérialiserObject(typeof(Color));
            remplissage = (Color)stream.DésérialiserObject(typeof(Color));
            épaisseur = (float)stream.DésérialiserObject(typeof(float));
            pt = (PointF)stream.DésérialiserObject(typeof(PointF));
            rayon = (float)stream.DésérialiserObject(typeof(float));
        }
    }
}
