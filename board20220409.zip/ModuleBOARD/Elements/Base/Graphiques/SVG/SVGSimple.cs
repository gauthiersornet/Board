﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Xml;
using ModuleBOARD.Réseau;

namespace ModuleBOARD.Elements.Base.Graphiques
{
    public class SVGSimple : Graphique
    {
        private SizeF taille;
        private List<Graphique> Dessus;

        public override (PointF, PointF) MinMax { get => (new PointF(-taille.Width / 2.0f, -taille.Height / 2.0f), new PointF(taille.Width / 2.0f, taille.Height / 2.0f)); }

        public SVGSimple()
        {
            Dessus = default;
        }

        public SVGSimple(List<Graphique> dessus)
        {
            Dessus = dessus;
            taille = CentrerEtDimensionner(Dessus);
        }

        public SVGSimple(string chmImg, string nomImg, BibliothèqueImage bibliothèqueImage)
        {
            Dessus = ChargerSVG(chmImg, nomImg, bibliothèqueImage);
            taille = CentrerEtDimensionner(Dessus);
        }

        public SVGSimple(string chmImg, XmlNode xmln, BibliothèqueImage bibliothèqueImage)
        {
            Dessus = ChargerSVG(chmImg, xmln, bibliothèqueImage);
            taille = CentrerEtDimensionner(Dessus);
        }

        override public GType GraphType { get => GType.SVGSimple; }
        override public object GraphiqueDessus { get => Dessus; }
        override public object GraphiqueDessous { get => Dessus; }

        override public void Centrer(PointF ctr) { if (Dessus != null) Dessus.ForEach(d => d.Centrer(ctr)); }

        override public Size Size { get => new Size((int)taille.Width, (int)taille.Height); }
        override public SizeF SizeF { get => taille; }
        override public void Dessiner(Graphics g, bool Retournée)
        {
            if (Dessus != null)
            {
                if (Retournée) for (int i = Dessus.Count - 1; i >= 0; --i) Dessus[i].Dessiner(g, Retournée);
                else Dessus.ForEach(d => d.Dessiner(g, Retournée));
            }
            else
            {
                RectangleF dRect = new RectangleF(-taille.Width / 2, -taille.Height / 2, taille.Width, taille.Height);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
            }
        }

        override public void MettreAJour(object obj)
        {
            if (Dessus != null) Dessus.ForEach(d => d.MettreAJour(obj));
        }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(taille);
            ushort nbc = (ushort)(Dessus?.Count ?? 0);
            stream.WriteBytes(BitConverter.GetBytes(nbc));
            for (ushort i = 0; i < nbc; ++i)
            {
                Graphique.Serialiser(Dessus[i], stream, null);
            }
        }

        public SVGSimple(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            taille = (SizeF)stream.DésérialiserObject(typeof(SizeF));
            ushort nbc = BitConverter.ToUInt16(stream.GetBytes(2), 0);
            if (nbc > 0)
            {
                Dessus = new List<Graphique>(nbc);
                for (ushort i = 0; i < nbc; ++i)
                    Dessus.Add(resscDes.RécupérerGraphique(stream, null));
            }
            else Dessus = null;
        }
    }
}
