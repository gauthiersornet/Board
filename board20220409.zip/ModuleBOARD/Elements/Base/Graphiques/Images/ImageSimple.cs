﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using ModuleBOARD.Réseau;

namespace ModuleBOARD.Elements.Base.Graphiques
{
    public class ImageSimple : Graphique
    {
        private Image Dessus;

        public ImageSimple()
        {
            Dessus = default;
        }

        public ImageSimple(Image img)
        {
            Dessus = img;
        }

        override public GType GraphType { get => GType.ImageSimple; }

        override public object GraphiqueDessus { get => Dessus; }
        override public object GraphiqueDessous { get => Dessus; }

        override public void Centrer(PointF ctr) { }

        override public Size Size { get { return new Size(Dessus?.Width ?? 20, Dessus?.Height ?? 20); } }
        override public SizeF SizeF { get { return new SizeF(Dessus?.Width ?? 20.0f, Dessus?.Height ?? 20.0f); } }

        /*override public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, RectangleF dRect, bool Retournée)
        {
            Matrix res;
            if (Dessus != null)
            {
                float sclRatio = GC.E / Math.Min(Dessus.Width, Dessus.Height);
                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                if (Retournée) g.ScaleTransform(-sclRatio, sclRatio);
                else g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                g.DrawImage(Dessus, dRect);
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);

            return res;
        }*/

        /*override public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, bool Retournée)
        {
            Matrix res;
            if (Dessus != null)
            {
                float sclRatio = GC.E / Math.Min(Dessus.Width, Dessus.Height);
                RectangleF dRect = new RectangleF(-Dessus.Width / 2, -Dessus.Height / 2, Dessus.Width, Dessus.Height);

                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                if(Retournée) g.ScaleTransform(-sclRatio, sclRatio);
                else g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                g.DrawImage(Dessus, dRect);
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);

            return res;
        }*/

        override public void Dessiner(Graphics g, bool Retournée)
        {
            if (Dessus != null)
            {
                RectangleF dRect = new RectangleF(-Dessus.Width / 2, -Dessus.Height / 2, Dessus.Width, Dessus.Height);
                if(Retournée)
                {
                    Matrix m = g.Transform;
                    g.ScaleTransform(-1.0f, 1.0f);
                    g.DrawImage(Dessus, dRect);
                    g.Transform = m;
                }
                else g.DrawImage(Dessus, dRect);
            }
            else g.FillRectangle(new SolidBrush(Color.Gray), new Rectangle(-10,-10,20,20));
        }

        /*override public Matrix DessinerVide(RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            if (Dessus.Width > 0 && Dessus.Height > 0)
            {
                float sclRatio = Math.Min(Dessus.Width, Dessus.Height);
                RectangleF dRect = new RectangleF(-Dessus.Width / 2, -Dessus.Height / 2, Dessus.Width, Dessus.Height);

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);
            return res;
        }*/

        override public void MettreAJour(object obj)
        {
            if (obj is Image)
            {
                Image img = obj as Image;
                if (Dessus != null && String.Equals(Dessus.Tag as string, img.Tag as string))
                    Dessus = img;
            }
        }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            if (vide != null && vide.GraphiqueDessus == Dessus) stream.WriteByte(0);
            else stream.SerialiserImage(Dessus);
        }

        public ImageSimple(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            Dessus = resscDes.RécupérerImage(stream);
            if (Dessus == null) Dessus = vide?.GraphiqueDessus as Image;
        }

        public override bool Equals(object obj)
        {
            if (base.Equals(obj)) return true;
            else if (obj is ImageSimple) return (obj as ImageSimple).Dessus == Dessus;
            else if (obj is Image) return (obj as Image) == Dessus;
            else return false;
        }

        public override int GetHashCode()
        {
            return (Dessus?.GetHashCode() ?? 0);
        }
    }
}
