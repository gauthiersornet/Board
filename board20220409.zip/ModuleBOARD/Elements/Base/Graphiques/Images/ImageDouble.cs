﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using ModuleBOARD.Réseau;

namespace ModuleBOARD.Elements.Base.Graphiques
{
    public class ImageDouble : Graphique
    {
        private Image Dessus;
        private Image Dessous;

        public ImageDouble()
        {
            Dessus = default;
            Dessous = default;
        }

        public ImageDouble(Image dessus, Image dessous)
        {
            Dessus = dessus;
            if (dessous == null) Dessous = Dessus;
            else Dessous = dessous;
        }

        public ImageDouble(Image dessus, Graphique dessous)
        {
            Dessus = dessus;
            if (dessous == null) Dessous = Dessus;
            else Dessous = dessous.GraphiqueDessous as Image;
        }

        public ImageDouble(Graphique dessus, Image dessous)
        {
            Dessus = dessus.GraphiqueDessous as Image;
            if (dessous == null) Dessous = Dessus;
            else Dessous = dessous;
        }

        public ImageDouble(Graphique dessus, Graphique dessous)
        {
            Dessus = dessus.GraphiqueDessous as Image;
            if (dessous == null) Dessous = Dessus;
            else Dessous = dessous.GraphiqueDessous as Image;
        }

        override public GType GraphType { get => GType.ImageDouble; }
        override public object GraphiqueDessus { get => Dessus; }
        override public object GraphiqueDessous { get => Dessous; }

        override public void Centrer(PointF ctr) { }

        override public Size Size { get { return new Size((Dessous ?? Dessus)?.Width ?? 20, (Dessous ?? Dessus)?.Height ?? 20); } }
        override public SizeF SizeF { get { return new SizeF((Dessous ?? Dessus)?.Width ?? 20.0f, (Dessous ?? Dessus)?.Height ?? 20.0f); } }

        /*override public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, RectangleF dRect, bool Retournée)
        {
            Matrix res;
            Image img = Retournée ? Dessous: Dessus;

            if (img != null)
            {
                float sclRatio = GC.E / Math.Min(img.Width, img.Height);
                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                g.DrawImage(img, dRect);
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);

            return res;
        }*/

        /*override public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, bool Retournée)
        {
            Matrix res;

            Image img = Retournée ? Dessous : Dessus;

            if (img != null)
            {
                float sclRatio = GC.E / Math.Min(img.Width, img.Height);
                RectangleF dRect = new RectangleF(-img.Width / 2, -img.Height / 2, img.Width, img.Height);

                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                if(Retournée) g.ScaleTransform(-sclRatio, sclRatio);
                else g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                g.DrawImage(img, dRect);
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);

            return res;
        }*/

        override public void Dessiner(Graphics g, bool Retournée)
        {
            Image img = Retournée ? Dessous : Dessus;
            if (img != null)
            {
                RectangleF dRect = new RectangleF(-img.Width / 2, -img.Height / 2, img.Width, img.Height);
                g.DrawImage(img, dRect);
            }
            else g.FillRectangle(new SolidBrush(Color.Gray), new Rectangle(-10, -10, 20, 20));
        }

        /*override public Matrix DessinerVide(RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            Image img = Dessous ?? Dessus;

            if (img.Width > 0 && img.Height > 0)
            {
                float sclRatio = Math.Min(img.Width, img.Height);
                RectangleF dRect = new RectangleF(-img.Width / 2, -img.Height / 2, img.Width, img.Height);

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);
            return res;
        }*/

        override public void MettreAJour(object obj)
        {
            if (obj is Image)
            {
                Image img = obj as Image;
                if (Dessus != null && String.Equals(Dessus.Tag as string, img.Tag as string))
                    Dessus = img;
                if (Dessous != null && String.Equals(Dessous.Tag as string, img.Tag as string))
                    Dessous = img;
            }
        }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            if (vide != null && vide.GraphiqueDessus == Dessus) stream.WriteByte(0);
            else stream.SerialiserObject(Dessus);
            if (vide != null && vide.GraphiqueDessous == Dessous) stream.WriteByte(0);
            else stream.SerialiserObject(Dessous);
        }

        public ImageDouble(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            Dessus = resscDes.RécupérerImage(stream);
            if (Dessus == null) Dessus = vide?.GraphiqueDessus as Image;
            Dessous = resscDes.RécupérerImage(stream);
            if (Dessous == null) Dessous = vide?.GraphiqueDessous as Image;
        }

        public override bool Equals(object obj)
        {
            if (base.Equals(obj)) return true;
            else if (obj is ImageDouble) return ((obj as ImageDouble).Dessus == Dessus && (obj as ImageDouble).Dessous == Dessous);
            else return false;
        }

        public override int GetHashCode()
        {
            return (Dessus?.GetHashCode() ?? 0) + (Dessous?.GetHashCode() ?? 0);
        }
    }
}
