﻿using ModuleBOARD.Elements.Base;
using ModuleBOARD.Elements.Lots.Piles;
using ModuleBOARD.Elements.Pieces;
using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ModuleBOARD.Elements.Lots
{
    public class Groupe : Element
    {
        //public Paquet Parent = null;
        private List<Element> LstElements = null;
        private List<IFigurine> LstFigurines = null;

        private float ancienAngleDessin = 0.0f;

        //public override bool EstParent { get => true; }
        public override EType ElmType { get => EType.Groupe; }
        public bool EstVide{ get => (LstElements == null || !LstElements.Any()) && (LstFigurines == null || !LstFigurines.Any()); }

        override public int ElmId { get => 0; set { } }

        public override PointF Size
        { 
            get => new PointF(float.MaxValue, float.MaxValue);
        }

        protected (PointF, PointF) PointFMinMax
        {
            get
            {
                PointF pmin = new PointF();
                PointF pmax = new PointF();

                if (LstElements != null)
                {
                    foreach(Element elm in LstElements)
                    {
                        float epi;
                        PointF sz = elm.Size;
                        float ray = Math.Max(sz.X, sz.Y) / 2.0f;

                        epi = elm.GC.P.X - ray;
                        if (epi < pmin.X) pmin.X = epi;
                        epi = elm.GC.P.Y - ray;
                        if (epi < pmin.Y) pmin.Y = epi;

                        epi = elm.GC.P.X + ray;
                        if (epi > pmax.X) pmax.X = epi;
                        epi = elm.GC.P.Y + ray;
                        if (epi > pmax.Y) pmax.Y = epi;
                    }
                }

                if (LstFigurines != null)
                {
                    foreach (Element elm in LstFigurines)
                    {
                        float epi;
                        PointF sz = elm.Size;
                        sz.X /= 2.0f; sz.Y /= 2.0f;

                        epi = elm.GC.P.X - sz.X;
                        if (epi < pmin.X) pmin.X = epi;
                        epi = elm.GC.P.Y - sz.Y;
                        if (epi < pmin.Y) pmin.Y = epi;

                        epi = elm.GC.P.X + sz.X;
                        if (epi > pmax.X) pmax.X = epi;
                        epi = elm.GC.P.Y + sz.Y;
                        if (epi > pmax.Y) pmax.Y = epi;
                    }
                }

                return (pmin, pmax);
            }
        }

        protected void Décaler(PointF delta)
        {
            if (LstElements != null)
            {
                foreach (Element elm in LstElements)
                {
                    elm.GC.P.X += delta.X;
                    elm.GC.P.Y += delta.Y;
                }
            }

            if (LstFigurines != null)
            {
                foreach (Element elm in LstFigurines)
                {
                    if (!(elm is Paquet))
                    {
                        elm.GC.P.X += delta.X;
                        elm.GC.P.Y += delta.Y;
                    }
                }
            }
        }

        /*public override bool IsAt(PointF mp, float angle)
        {
            return true;
        }*/

        /*public override bool IsAt(PointF mp, PointF psz, float angle)
        {
            if (psz.X == float.MaxValue && psz.Y == float.MaxValue) return true;
            else return base.IsAt(mp, psz, angle);
        }*/

        public Groupe()
        {
            base.MajEtat(EEtat.RotationFixe | EEtat.PositionFixe);
        }

        public Groupe(Groupe elm)
            :base(elm)
        {
            base.MajEtat(EEtat.RotationFixe | EEtat.PositionFixe);
            LstElements = (elm.LstElements != null ? new List<Element>(elm.LstElements) : null);
            LstFigurines = (elm.LstFigurines != null ? new List<IFigurine>(elm.LstFigurines) : null);
        }

        public Groupe(string path, XmlNode paq, PointF p, Dictionary<string, Element> _dElements, BibliothèqueImage bibliothèqueImage, BibliothèqueModel bibliothèqueModel)
        {
            base.MajEtat(EEtat.RotationFixe | EEtat.PositionFixe);

            if (_dElements == null) _dElements = new Dictionary<string, Element>();
            base.Load(paq);
            GC.P.X += p.X;
            GC.P.Y += p.Y;

            //PointF pZero = new PointF(0.0f, 0.0f);
            LstElements = new List<Element>();
            LstFigurines = new List<IFigurine>();
            foreach (XmlNode xmln in paq.ChildNodes)
            {
                Element elm = Charger(path, xmln, new PointF(0.0f, 0.0f), _dElements, bibliothèqueImage, bibliothèqueModel);
                /*switch (xmln.Name.ToUpper().Trim())
                {
                    case "GROUPE": elm = new Groupe(path, xmln, pZero, _dElements, bibliothèqueImage, bibliothèqueModel); break;
                    case "PILE": elm = new Pile(path, xmln, pZero, bibliothèqueImage); break;
                    case "PIOCHE": elm = new Pioche(path, xmln, pZero, bibliothèqueImage); break;
                    case "DEFFAUSE": elm = new Défausse(path, xmln, pZero, bibliothèqueImage); break;
                    case "PAQUET": elm = new Paquet(path, xmln, pZero, _dElements, bibliothèqueImage, bibliothèqueModel); break;
                    case "FIGURINE": elm = new Figurine(path, xmln, pZero, bibliothèqueImage, bibliothèqueModel); break;
                    default: elm = null; break;
                }*/
                if (elm != null)
                {
                    string nom = xmln.Attributes?.GetNamedItem("nom")?.Value;
                    if (nom != null) _dElements.Add(nom, elm);
                    if ((elm is IFigurine) == false || elm is Paquet) LstElements.Add(elm);
                    if (elm is IFigurine) AddFigurine(elm as IFigurine);
                }
            }
            _lier(paq.ChildNodes, _dElements);
            if (LstElements.Any()) LstElements.Sort();
            else LstElements = null;
            if (LstFigurines.Any() == false) LstFigurines = null;
        }

        private void AddFigurine(IFigurine fig)
        {
            if (LstFigurines == null) LstFigurines = new List<IFigurine>();
            LstFigurines.Add(fig);
            MettreAJourZOrdre(fig);
        }

        public void MettreAJourOrdre(int idx)
        {
            if (LstElements != null && 0 <= idx && idx < LstElements.Count)
            {
                Element elm = LstElements[idx];
                for (; idx > 0 && (LstElements[idx - 1].Ordre > elm.Ordre); --idx)
                {
                    LstElements[idx] = LstElements[idx - 1];
                }
                for (; idx < (LstElements.Count - 1) && (LstElements[idx + 1].Ordre < elm.Ordre); ++idx)
                {
                    LstElements[idx] = LstElements[idx + 1];
                }
                LstElements[idx] = elm;
            }
        }

        public void MettreAJourZOrdre(IFigurine fig)
        {
            if (LstFigurines != null)
            {
                int fidx;
                for (fidx = 0; fidx < LstFigurines.Count && Object.ReferenceEquals(fig, LstFigurines[fidx]) == false; ++fidx) ;
                if(fidx < LstFigurines.Count)
                {
                    fig.Z = CalculerFigurineZ(fig, ancienAngleDessin);
                    for (; fidx > 0 && (LstFigurines[fidx - 1].Z < fig.Z); --fidx)
                    {
                        LstFigurines[fidx] = LstFigurines[fidx - 1];
                    }
                    for (; fidx < (LstFigurines.Count-1) && (LstFigurines[fidx + 1].Z > fig.Z); ++fidx)
                    {
                        LstFigurines[fidx] = LstFigurines[fidx + 1];
                    }
                    LstFigurines[fidx] = fig;
                }
            }
        }

        private bool _lier(XmlNodeList paqL, Dictionary<string, Element> dElements)
        {
            if (paqL.Count == (LstElements?.Count ?? 0 + LstFigurines?.Count ?? 0))
            {
                int i = 0;
                int ifig = 0;
                foreach (XmlNode xmln in paqL)
                {
                    if(xmln.Name.ToUpper().Trim() == "FIGURINE")
                        (LstFigurines[ifig++] as Element).Lier(xmln, dElements);
                    else LstElements[i++].Lier(xmln, dElements);
                }

                return true;
            }
            else return false;
        }

        public override void Dessiner(ushort idJoueur, RectangleF vue, float angle, Graphics g, bool retourné = false)
        {
            /*p.X -= GC.P.X;
            p.Y -= GC.P.Y;*/
            Matrix svMat = g.Transform;
            g.TranslateTransform(GC.P.X, GC.P.Y);
            if (GC.A != 0.0f)
            {
                g.RotateTransform(GC.A);
                angle += GC.A;
            }
            if (LstElements != null)
            {
                retourné ^= EstDansEtat(EEtat.Retournée);
                if (retourné)
                {
                    for (int i = 0; i < LstElements.Count; ++i)
                    {
                        if (LstElements[i] != null)
                            LstElements[i].Dessiner(idJoueur, vue, angle, g, retourné);
                    }
                }
                else
                {
                    for (int i = LstElements.Count - 1; i >= 0; --i)
                    {
                        if (LstElements[i] != null)
                            LstElements[i].Dessiner(idJoueur, vue, angle, g, retourné);
                    }
                }
            }
            if (LstFigurines != null)
            {
                if (ancienAngleDessin != angle) TrierZFigurine(angle);
                for (int i = LstFigurines.Count - 1; i >= 0; --i)
                {
                    if (LstFigurines[i] != null)
                        LstFigurines[i].DessinerFigurine(idJoueur, vue, angle, g);
                }
            }
            g.Transform = svMat;
        }

        public void TrierZFigurine(float angle)
        {
            ancienAngleDessin = angle;
            if (LstFigurines != null)
            {
                double dAng = angle * (Math.PI / 180.0);
                double cos = Math.Cos(dAng);
                double sin = Math.Sin(dAng);
                LstFigurines.ForEach(f => f.Z = (float)(sin * (f as Element).GC.P.X + cos * (f as Element).GC.P.Y));
                LstFigurines.Sort(new FigurineZComparer());
            }
        }

        static public float CalculerFigurineZ(IFigurine fig, float angle)
        {
            if (fig != null)
            {
                double dAng = angle * (Math.PI / 180.0);
                double cos = Math.Cos(dAng);
                double sin = Math.Sin(dAng);
                return (float)(sin * (fig as Element).GC.P.X + cos * (fig as Element).GC.P.Y);
            }
            else return 0.0f;
        }

        /// <summary>
        /// Retourne l'élément recherché puis le conteneur
        /// </summary>
        /// <param name="netId"></param>
        /// <returns>(Element, Conteneur)</returns>
        public override (Element, Element) MousePickAvecContAt(int netId, ushort idJr, EPickUpAction action)
        {
            if (netId == IdentifiantRéseau) return (this, null);

            Element felm, conteneur;
            //(felm, conteneur) = base.MousePickAvecContAt(netId);
            /*if (felm == null)
            {*/
                if (LstFigurines != null)
                {
                    for (int i = 0; i < LstFigurines.Count; ++i)
                        if (LstFigurines[i] != null)
                        {
                            (felm, conteneur) = (LstFigurines[i] as Element).MousePickAvecContAt(netId, idJr, action);
                            if (felm != null)
                            {
                                if (conteneur != null) return (felm, conteneur);
                                else return (felm, this);
                            }
                        }
                }

                if (LstElements != null)
                {
                    for (int i = 0; i < LstElements.Count; ++i)
                        if (LstElements[i] != null)
                        {
                            (felm, conteneur) = LstElements[i].MousePickAvecContAt(netId, idJr, action);
                            if (felm != null)
                            {
                                if (conteneur != null) return (felm, conteneur);
                                else return (felm, this);
                            }
                        }
                }

                return (null, null);
            /*}
            else return (felm, conteneur);*/
        }

        public override (List<Element>, Element) MouseCatchAvecContAt(HashSet<int> netIds, ushort idJr, EPickUpAction action)
        {
            if (netIds.Contains(IdentifiantRéseau))
            {
                netIds.Remove(IdentifiantRéseau);
                return (new List<Element>() { this }, null);
            }

            (List<Element>, Element) res = (null, null);
            //(felm, conteneur) = base.MousePickAvecContAt(netId);
            /*if (felm == null)
            {*/
            if (LstFigurines != null)
            {
                for (int i = LstFigurines.Count - 1; i >= 0  && netIds.Any(); --i)
                    if (LstFigurines[i] != null)
                    {
                        var resCatch = (LstFigurines[i] as Element).MouseCatchAvecContAt(netIds, idJr, action);
                        if (resCatch.Item1 != null)
                        {
                            if (resCatch.Item2 == null) resCatch = (resCatch.Item1, this);
                            if (res.Item1 == null) res = resCatch;
                            else if (resCatch.Item2 == res.Item2) res.Item1.AddRange(resCatch.Item1);
                        }
                    }
            }

            if (LstElements != null)
            {
                for (int i = LstElements.Count - 1; i >= 0  && netIds.Any(); --i)
                    if (LstElements[i] != null)
                    {
                        var resCatch = (LstElements[i] as Element).MouseCatchAvecContAt(netIds, idJr, action);
                        if (resCatch.Item1 != null)
                        {
                            if (resCatch.Item2 == null) resCatch = (resCatch.Item1, this);
                            if (res.Item1 == null) res = resCatch;
                            else if (resCatch.Item2 == res.Item2) res.Item1.AddRange(resCatch.Item1);
                        }
                    }
            }

            return (null, null);
            /*}
            else return (felm, conteneur);*/
        }

        //(Element, Conteneur)
        public override (Element, Element) MousePickAvecContAt(PointF mp, float angle, ushort idJr, EPickUpAction action = 0)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;

            if (GC.A != 0.0f)
            {
                Matrix m = new Matrix();
                m.Rotate(GC.A);
                mp = new PointF
                    (
                        mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                        mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                    );
                angle += GC.A;
            }

            PointF sz = Size;
            if(sz.X != float.MaxValue && sz.Y != float.MaxValue)
            {
                sz.X /= 2.0f;
                sz.Y /= 2.0f;
                if((mp.X < -sz.X || sz.X < mp.X) || (mp.Y < -sz.Y || sz.Y < mp.Y))
                {
                    return (null, null);
                }
            }

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        Element felm, conteneur;
                        (felm, conteneur) = (LstFigurines[i] as Element).MousePickAvecContAt(mp, angle, idJr, action);
                        if (felm != null)
                        {
                            if (conteneur != null) return (felm, conteneur);
                            else return (felm, this);
                        }
                    }
            }

            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        Element felm, conteneur;
                        (felm, conteneur) = LstElements[i].MousePickAvecContAt(mp, angle, idJr, action);
                        if (felm != null)
                        {
                            if (conteneur != null) return (felm, conteneur);
                            else return (felm, this);
                        }
                    }
            }

            return (this, this);
        }

        public override (List<Element>, Element) MouseCatchAvecContAt(PointF mp, float angle, ushort idJr, EPickUpAction action)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;

            if (GC.A != 0.0f)
            {
                Matrix m = new Matrix();
                m.Rotate(GC.A);
                mp = new PointF
                    (
                        mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                        mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                    );
                angle += GC.A;
            }

            PointF sz = Size;
            if (sz.X != float.MaxValue && sz.Y != float.MaxValue)
            {
                sz.X /= 2.0f;
                sz.Y /= 2.0f;
                if ((mp.X < -sz.X || sz.X < mp.X) || (mp.Y < -sz.Y || sz.Y < mp.Y))
                {
                    return (null, null);
                }
            }

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        var elms = (LstFigurines[i] as Element).MouseCatchAvecContAt(mp, angle, idJr, action);
                        if (elms.Item1 != null)
                        {
                            if (elms.Item2 != null) return (elms.Item1, elms.Item2);
                            else return (elms.Item1, this);
                        }
                    }
            }

            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        var elms = LstElements[i].MouseCatchAvecContAt(mp, angle, idJr, action);
                        if (elms.Item1 != null)
                        {
                            if (elms.Item2 != null) return (elms.Item1, elms.Item2);
                            else
                            {
                                Element elm = elms.Item1.First();
                                PointF psz = elm.Size;
                                psz.X /= 2.0f; psz.Y /= 2.0f;
                                Matrix m = new Matrix();
                                m.Rotate(-elm.GC.A);
                                for (--i; i >= 0; --i)
                                {
                                    PointF dp = LstElements[i].GC.P;
                                    dp.X -= elm.GC.P.X;
                                    dp.Y -= elm.GC.P.Y;
                                    PointF nmp = new PointF
                                        (
                                            dp.X * m.Elements[0] + dp.Y * m.Elements[1],
                                            dp.X * m.Elements[2] + dp.Y * m.Elements[3]
                                        );
                                    if (-psz.X <= nmp.X && -psz.Y <= nmp.Y && nmp.X <= psz.X && nmp.Y <= psz.Y)
                                        elms.Item1.Add(LstElements[i]);
                                }
                                if (LstFigurines != null)
                                {
                                    for (i = LstFigurines.Count - 1; i >= 0; --i)
                                    {
                                        PointF dp = (LstFigurines[i] as Element).GC.P;
                                        dp.X -= elm.GC.P.X;
                                        dp.Y -= elm.GC.P.Y;
                                        PointF nmp = new PointF
                                            (
                                                dp.X * m.Elements[0] + dp.Y * m.Elements[1],
                                                dp.X * m.Elements[2] + dp.Y * m.Elements[3]
                                            );
                                        if (-psz.X <= nmp.X && -psz.Y <= nmp.Y && nmp.X <= psz.X && nmp.Y <= psz.Y)
                                            elms.Item1.Add((LstFigurines[i] as Element));
                                    }
                                }
                                return (elms.Item1, this);
                            }
                        }
                    }
            }

            return (new List<Element>() { this }, null);
        }

        /*public override (List<Element>, Element) MousePickAllAvecContAt(PointF mp, float angle, EPickUpAction action = 0)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;

            if (GC.A != 0.0f)
            {
                Matrix m = new Matrix();
                m.Rotate(GC.A);
                mp = new PointF
                    (
                        mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                        mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                    );
                angle += GC.A;
            }

            PointF sz = Size;
            if (sz.X != float.MaxValue && sz.Y != float.MaxValue)
            {
                sz.X /= 2.0f;
                sz.Y /= 2.0f;
                if ((mp.X < -sz.X || sz.X < mp.X) || (mp.Y < -sz.Y || sz.Y < mp.Y))
                {
                    return (null, null);
                }
            }

            (List<Element>, Element) res = (null, null);

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        (List<Element>, Element) lst = (LstFigurines[i] as Element).MousePickAllAvecContAt(mp, angle, action);
                        if(lst.Item1 != null)
                        {
                            if(lst.Item2 == null) lst = (lst.Item1, this);
                            if (res.Item2 == null) res = lst;
                            else if (res.Item2 == lst.Item2) res.Item1.AddRange(lst.Item1);
                        }
                    }
            }

            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        (List<Element>, Element) lst = LstElements[i].MousePickAllAvecContAt(mp, angle, action);
                        if (lst.Item1 != null)
                        {
                            if (lst.Item2 == null) lst = (lst.Item1, this);
                            if (res.Item2 == null) res = lst;
                            else if (res.Item2 == lst.Item2) res.Item1.AddRange(lst.Item1);
                        }
                    }
            }

            return res;
        }*/

        public override Element MousePickAt(int netId, ushort idJr, Element.EPickUpAction action)
        {
            Element elm = base.MousePickAt(netId, idJr, action);
            if(elm == null)
            {
                if (LstFigurines != null)
                {
                    for (int i = 0; i < LstFigurines.Count; ++i)
                        if (LstFigurines[i] != null)
                        {
                            Element felm = (LstFigurines[i] as Element).MousePickAt(netId, idJr, action);
                            if (felm != null) return felm;
                        }
                }

                if (LstElements != null)
                {
                    for (int i = 0; i < LstElements.Count; ++i)
                        if (LstElements[i] != null)
                        {
                            Element felm = LstElements[i].MousePickAt(netId, idJr, action);
                            if (felm != null) return felm;
                        }
                }

                return null;
            }
            else return elm;
        }

        public override Element MousePickAt(PointF mp, float angle, ushort idJr , EPickUpAction action)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;

            if (GC.A != 0.0f)
            {
                Matrix m = new Matrix();
                m.Rotate(GC.A);
                mp = new PointF
                    (
                        mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                        mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                    );
                angle += GC.A;
            }

            PointF sz = Size;
            if (sz.X != float.MaxValue && sz.Y != float.MaxValue)
            {
                sz.X /= 2.0f;
                sz.Y /= 2.0f;
                if ((mp.X < -sz.X || sz.X < mp.X) || (mp.Y < -sz.Y || sz.Y < mp.Y))
                {
                    return null;
                }
            }

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        Element felm = (LstFigurines[i] as Element).MousePickAt(mp, angle, idJr, action);
                        if (felm != null) return felm;
                    }
            }

            if (LstElements != null)
            {
                for (int i=0;i< LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        Element felm = LstElements[i].MousePickAt(mp, angle, idJr, action);
                        if (felm != null)return felm;
                    }
            }

            return this;
        }

        public override List<Element> MouseCatchAt(PointF mp, float angle, ushort idJr , EPickUpAction action)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;

            if (GC.A != 0.0f)
            {
                Matrix m = new Matrix();
                m.Rotate(GC.A);
                mp = new PointF
                    (
                        mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                        mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                    );
                angle += GC.A;
            }

            PointF sz = Size;
            if (sz.X != float.MaxValue && sz.Y != float.MaxValue)
            {
                sz.X /= 2.0f;
                sz.Y /= 2.0f;
                if ((mp.X < -sz.X || sz.X < mp.X) || (mp.Y < -sz.Y || sz.Y < mp.Y))
                {
                    return null;
                }
            }

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        List<Element> felms = (LstFigurines[i] as Element).MouseCatchAt(mp, angle, idJr, action);
                        if (felms != null && felms.Any()) return felms;
                    }
            }

            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        List<Element> elms = LstElements[i].MouseCatchAt(mp, angle, idJr, action);
                        if (elms != null && elms.Any())
                        {
                            Element elm = elms.First();
                            PointF psz = elm.Size;
                            psz.X /= 2.0f; psz.Y /= 2.0f;
                            Matrix m = new Matrix();
                            m.Rotate(-elm.GC.A);
                            for (--i; i >= 0; --i)
                            {
                                PointF dp = LstElements[i].GC.P;
                                dp.X -= elm.GC.P.X;
                                dp.Y -= elm.GC.P.Y;
                                PointF nmp = new PointF
                                    (
                                        dp.X * m.Elements[0] + dp.Y * m.Elements[1],
                                        dp.X * m.Elements[2] + dp.Y * m.Elements[3]
                                    );
                                if (-psz.X <= nmp.X && -psz.Y <= nmp.Y && nmp.X <= psz.X && nmp.Y <= psz.Y)
                                    elms.Add(LstElements[i]);
                            }
                            if (LstFigurines != null)
                            {
                                for (i = LstFigurines.Count - 1; i >= 0; --i)
                                {
                                    PointF dp = (LstFigurines[i] as Element).GC.P;
                                    dp.X -= elm.GC.P.X;
                                    dp.Y -= elm.GC.P.Y;
                                    PointF nmp = new PointF
                                        (
                                            dp.X * m.Elements[0] + dp.Y * m.Elements[1],
                                            dp.X * m.Elements[2] + dp.Y * m.Elements[3]
                                        );
                                    if (-psz.X <= nmp.X && -psz.Y <= nmp.Y && nmp.X <= psz.X && nmp.Y <= psz.Y)
                                        elms.Add((LstFigurines[i] as Element));
                                }
                            }
                            return elms;
                        }

                    }
            }

            return new List<Element>() { this };
        }
        

        public override List<Element> MouseCatchAt(HashSet<int> netIds, ushort idJr , EPickUpAction action)
        {
            List<Element> elms = base.MouseCatchAt(netIds, idJr, action);
            if (elms == null)
            {
                if (LstElements != null)
                {
                    for (int i = LstElements.Count - 1; i >= 0 && netIds.Any(); --i)
                        if (LstElements[i] != null)
                        {
                            List<Element> felms = LstElements[i].MouseCatchAt(netIds, idJr, action);
                            if (felms != null)
                            {
                                if (elms == null) elms = felms;
                                else elms.AddRange(felms);
                            }
                        }
                }

                if (LstFigurines != null)
                {
                    for (int i = LstFigurines.Count - 1; i >= 0 && netIds.Any(); --i)
                        if (LstFigurines[i] != null)
                        {
                            List<Element> felms = (LstFigurines[i] as Element).MouseCatchAt(netIds, idJr, action);
                            if (felms != null)
                            {
                                if (elms == null) elms = felms;
                                else elms.AddRange(felms);
                            }
                        }
                }

                return elms;
            }
            else return elms;
        }

        public override (List<Element>, Element) MouseCatchAllInAvecContAt(PointF mpDb, PointF mpFn, Matrix m, ushort idJr, EPickUpAction action)
        {
            //m.Rotate(-angle);
            PointF gp = new PointF
                (
                    GC.P.X * m.Elements[0] + GC.P.Y * m.Elements[1],
                    GC.P.X * m.Elements[2] + GC.P.Y * m.Elements[3]
                );

            mpDb.X -= gp.X;
            mpDb.Y -= gp.Y;
            mpFn.X -= gp.X;
            mpFn.Y -= gp.Y;

            m.Rotate(-GC.A);

            //Si paravent, l'attraper sir ces 2 coins extrèmes sont dans la zone...
            /*PointF sz = Size;
            if (sz.X != float.MaxValue && sz.Y != float.MaxValue)
            {
                sz.X /= 2.0f;
                sz.Y /= 2.0f;
                if ((mp.X < -sz.X || sz.X < mp.X) || (mp.Y < -sz.Y || sz.Y < mp.Y))
                {
                    return (null, null);
                }
            }*/

            List<Element> elmRes = null;
            Element contRes = null;

            List<(PointF, Matrix)> elmSzMatPourFig = null;

            if (LstElements != null)
            {
                for (int i = LstElements.Count - 1; i >= 0 ; --i)
                    if (LstElements[i] != null)
                    {
                        var elms = LstElements[i].MouseCatchAllInAvecContAt(mpDb, mpFn, m, idJr, action);
                        if (elms.Item1 != null)
                        {
                            if (elms.Item2 == null) elms = (elms.Item1, this);

                            if (elmRes == null)
                            {
                                if (elms.Item2 == this) (elmRes, contRes) = (new List<Element>(), elms.Item2);
                                else return elms;
                            }
                            
                            if(elms.Item2 == this)
                            {
                                List<(PointF, Matrix)> elmSzMat = elms.Item1.Select(e => (e.HalfSize, e.GC.ObtenirMatriceProjection)).ToList();
                                if (elmSzMatPourFig == null) elmSzMatPourFig = elmSzMat;
                                else elmSzMatPourFig.AddRange(elmSzMat);
                                elmRes.AddRange(elms.Item1.Where(e => !elmRes.Contains(e)).ToList());
                                for (int idx = i - 1; idx >= 0; --idx)
                                {
                                    if (!elmRes.Contains(LstElements[idx]) && elmSzMat.Any(e => LstElements[idx].IsIn(e.Item1, e.Item2)))
                                        elmRes.Add(LstElements[idx]);
                                }
                            }
                        }
                    }
            }

            if (LstFigurines != null)
            {
                for (int i = LstFigurines.Count-1; i >= 0; --i)
                    if (LstFigurines[i] != null)
                    {
                        var elms = (LstFigurines[i] as Element).MouseCatchAllInAvecContAt(mpDb, mpFn, m, idJr, action);
                        if (elms.Item1 != null)
                        {
                            if (elms.Item2 == null) elms = (elms.Item1, this);
                            if (elmRes == null) (elmRes, contRes) = elms;
                            else if (contRes == elms.Item2) elmRes.AddRange(elms.Item1);
                        }
                        else if (elmSzMatPourFig != null && !elmRes.Contains(LstFigurines[i] as Element) && elmSzMatPourFig.Any(e => (LstFigurines[i] as Element).IsIn(e.Item1, e.Item2)))
                            elmRes.Add(LstFigurines[i] as Element);
                    }
            }

            return (null, null);
        }

        /*public override List<Element> MousePickAllAt(PointF mp, float angle, EPickUpAction action = 0)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;
            if (GC.A != 0.0f)
            {
                Matrix m = new Matrix();
                m.Rotate(GC.A);
                mp = new PointF
                    (
                        mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                        mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                    );
            }

            List<Element> res = null;

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        List<Element> felm = (LstFigurines[i] as Element).MousePickAllAt(mp, angle, action);
                        if (felm != null)
                        {
                            if (res == null) res = felm;
                            else res.AddRange(felm);
                        }
                    }
            }

            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        List<Element> felm = LstElements[i].MousePickAllAt(mp, angle, action);
                        if (felm != null)
                        {
                            if (res == null) res = felm;
                            else res.AddRange(felm);
                        }
                    }
            }

            return res;
        }*/

        /*public override Element MousePiocheAt(PointF mp, float angle)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        Element felm = (LstFigurines[i] as Element).MousePiocheAt(mp, angle);
                        if (felm != null)
                        {
                            if (LstFigurines[i] == felm)
                            {
                                LstFigurines.RemoveAt(i);
                                if (LstFigurines.Count == 0) LstFigurines = null;
                                if (felm is Paquet)
                                {
                                    LstElements.Remove(felm);
                                    if (LstElements.Count == 0) LstElements = null;
                                }
                            }
                            felm.GC.P.X += GC.P.X;
                            felm.GC.P.Y += GC.P.Y;
                            return felm;
                        }
                    }
            }

            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        Element felm = LstElements[i].MousePiocheAt(mp, angle);
                        if (felm != null)
                        {
                            if(LstElements[i] == felm)
                            {
                                LstElements.RemoveAt(i);
                                if (LstElements.Count == 0) LstElements = null;
                            }
                            felm.GC.P.X += GC.P.X;
                            felm.GC.P.Y += GC.P.Y;
                            return felm;
                        }
                    }
            }
            return null;
        }*/

        public override Element ElementLaché(Element elm)
        {
            Add(elm);
            return null;
        }

        public Element Fusionner(Element elm)
        {
            if (elm != null)
            {
                if (elm.ElmType == EType.Groupe) Fusionner(elm as Groupe);
                else
                {
                    /*elm.GC.P.X -= GC.P.X;
                    elm.GC.P.Y -= GC.P.X;*/
                    elm.GC.Projection(GC);
                    if (elm is IFigurine)
                    {
                        if (LstFigurines == null) LstFigurines = new List<IFigurine>();
                        AddFigurine(elm as IFigurine);
                    }
                    if (elm is IFigurine == false || elm is Paquet)
                    {
                        if (LstElements == null) LstElements = new List<Element>();
                        LstElements.Add(elm);
                        PutAt(LstElements.Count - 1, trouverOrdreIdx(elm.Ordre));
                    }
                }
            }
            return null;
        }

        public Groupe Fusionner(Groupe pq)
        {
            if (pq!=null)
            {
                if (pq.LstFigurines != null && pq.LstFigurines.Count > 0)
                {
                    foreach (Element elm in pq.LstFigurines)
                    {
                        elm.GC.ProjectionInv(pq.GC);
                        /*elm.GC.P.X += pq.GC.P.X;
                        elm.GC.P.Y += pq.GC.P.Y;*/

                        elm.GC.Projection(GC);
                        /*elm.GC.P.X -= GC.P.X;
                        elm.GC.P.Y -= GC.P.Y;*/
                    }

                    if (LstFigurines != null)
                    {
                        LstFigurines.AddRange(pq.LstFigurines);
                        pq.LstFigurines.Clear();
                    }
                    else LstFigurines = pq.LstFigurines;
                    pq.LstFigurines = null;
                    if (LstFigurines != null && LstFigurines.Count == 0)
                        LstFigurines = null;
                    TrierZFigurine(ancienAngleDessin);
                }
                if (pq.LstElements != null && pq.LstElements.Count > 0)
                {
                    foreach (Element elm in pq.LstElements)
                    {
                        elm.GC.ProjectionInv(pq.GC);
                        /*elm.GC.P.X += pq.GC.P.X;
                        elm.GC.P.Y += pq.GC.P.Y;*/

                        elm.GC.Projection(GC);
                        /*elm.GC.P.X -= GC.P.X;
                        elm.GC.P.Y -= GC.P.Y;*/
                    }

                    if (LstElements == null) LstElements = new List<Element>();
                    /*int idxToTop = LstElements.Count;
                    LstElements.AddRange(pq.LstElements);*/
                    int idxToTop = 0;
                    foreach(Element elm in pq.LstElements)
                    {
                        if (elm is Groupe) Fusionner(elm as Groupe);
                        else
                        {
                            ++idxToTop;
                            LstElements.Add(elm);
                        }
                    }
                    for (int i = 0; idxToTop + i < LstElements.Count; ++i)
                    {
                        PutAt(idxToTop + i, i);
                    }
                    pq.LstElements.Clear();

                    pq.LstElements = null;
                    if (LstElements != null && LstElements.Count == 0)
                        LstElements = null;

                    LstElements.Sort();
                }
            }
            return null;
        }

        private Element Add(Element elm)
        {
            if (elm != null && (elm.ElmType != EType.Groupe && (this is Groupe || ElmType != EType.ParAVent)))
            {
                /*elm.GC.P.X -= GC.P.X;
                elm.GC.P.Y -= GC.P.Y;*/
                elm.GC.Projection(GC);
                if (elm is IFigurine)
                {
                    AddFigurine(elm as IFigurine);
                }
                if (elm is IFigurine == false || elm is Paquet)
                {
                    if (LstElements == null) LstElements = new List<Element>();
                    LstElements.Add(elm);
                    if (LstElements.Count > 1)
                        PutAt(LstElements.Count - 1, trouverOrdreIdx(elm.Ordre));
                }
                return null;
            }
            else return elm;
        }

        public Element AddBack(Element elm)
        {
            if (elm != null && (elm is Groupe) == false)
            {
                elm.GC.P.X -= GC.P.X;
                elm.GC.P.Y -= GC.P.Y;
                if (elm is IFigurine)
                {
                    AddFigurine(elm as IFigurine);

                }
                if (elm is IFigurine == false || elm is Paquet)
                {
                    if (LstElements == null) LstElements = new List<Element>();
                    LstElements.Add(elm);
                }
                return null;
            }
            else return elm;
        }

        private int trouverOrdreIdx(sbyte ordre)
        {
            int inf = 0;
            int sup = LstElements.Count;
            while(inf < sup)
            {
                int mid = (inf / sup) / 2;
                sbyte midOrdre = LstElements[mid].Ordre;
                if (midOrdre == ordre)
                    inf = sup = mid;
                else if (midOrdre > ordre)
                {
                    if (mid == inf) inf = sup;
                    else inf = mid;
                }
                else //if((ordre > midOrdre))
                {
                    if (mid == sup) sup = inf;
                    else sup = mid;
                }
            }
            return inf;
        }

        public override void Tourner(int delta) { }

        /*private int trouverZOrdreIdx(float ordre)
        {
            int inf = 0;
            int sup = LstFigurines.Count;
            while (inf < sup)
            {
                int mid = (inf / sup) / 2;
                float midOrdre = LstFigurines[mid].Z;
                if (midOrdre == ordre)
                    inf = sup = mid;
                else if (midOrdre > ordre)
                {
                    if (mid == inf) inf = sup;
                    else inf = mid;
                }
                else //if((ordre > midOrdre))
                {
                    if (mid == sup) sup = inf;
                    else sup = mid;
                }
            }
            return inf;
        }*/

        public Element AddTop(Element elm)
        {
            if (elm != null && (elm is Groupe) == false)
            {
                elm.GC.P.X -= GC.P.X;
                elm.GC.P.Y -= GC.P.Y;
                if (elm is IFigurine)
                {
                    AddFigurine(elm as IFigurine);
                }
                if (elm is IFigurine == false || elm is Paquet)
                {
                    if (LstElements == null) LstElements = new List<Element>();
                    LstElements.Add(elm);
                    if (LstElements.Count > 1) PutAt(LstElements.Count - 1, 0);
                }
                return null;
            }
            else return elm;
        }

        private void PutAt(int ielem, int at)
        {
            if (LstElements != null && ielem < LstElements.Count)
            {
                if (at < 0) at = 0;
                else if (LstElements.Count <= at) at = LstElements.Count - 1;

                if (ielem != at)
                {
                    Element elm = LstElements[ielem];

                    if (at < ielem)
                        for (int i = ielem; i > at; --i)
                            LstElements[i] = LstElements[i - 1];
                    else if (at > ielem)
                        for (int i = ielem; i < at; ++i)
                            LstElements[i] = LstElements[i + 1];

                    LstElements[at] = elm;
                    MettreAJourOrdre(at);
                }
            }
        }

        private bool PutAt(Element elm, int idxD)
        {
            if (LstElements != null)
            {
                int idx = LstElements.IndexOf(elm);
                if (idx >= 0)
                {
                    PutAt(idx, idxD);
                    return true;
                }
                else return false;
            }
            else return false;
        }

        private void PutTop(int idx)
        {
            if (0<= idx && idx < LstElements.Count)
            {
                PutAt(idx, trouverOrdreIdx(LstElements[idx].Ordre));
            }
        }

        private bool PutTop(Element elm)
        {
            return PutAt(elm, 0);
        }

        private void PutFigAt(int ielem, int at)
        {
            if (LstFigurines != null && ielem < LstFigurines.Count)
            {
                if (at < 0) at = 0;
                else if (LstFigurines.Count <= at) at = LstFigurines.Count - 1;

                if (ielem != at)
                {
                    IFigurine elm = LstFigurines[ielem];

                    if (at < ielem)
                        for (int i = ielem; i > at; --i)
                            LstFigurines[i] = LstFigurines[i - 1];
                    else if (at > ielem)
                        for (int i = ielem; i < at; ++i)
                            LstFigurines[i] = LstFigurines[i + 1];

                    LstFigurines[at] = elm;
                }
            }
        }

        /*public override void MajEtat(EEtat nouvEtat)
        {
            if(AEtatChangé(EEtat.Retournée, nouvEtat))
            {
                if (LstFigurines != null)
                {
                    foreach (Element elm in LstFigurines)
                        elm.Retourner();
                }
                if (LstElements != null)
                {
                    foreach (Element elm in LstElements)
                        elm.Retourner();
                }
            }
            base.MajEtat(nouvEtat);
        }*/

        public override bool Roulette(int delta)
        {
            return false;
        }

        /*public override Element MouseRangerAt(PointF mp, float angle)
        {
            mp.X -= GC.P.X;
            mp.Y -= GC.P.Y;

            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        Element elm = (LstFigurines[i] as Element).MouseRangerAt(mp, angle);
                        if (LstFigurines[i] == elm)
                        {
                            LstFigurines.RemoveAt(i);
                            if (LstFigurines.Count == 0) LstFigurines = null;
                            if (elm is Paquet)
                            {
                                LstElements.Remove(elm);
                                if (LstElements.Count == 0) LstElements = null;
                            }
                            return elm;
                        }
                    }
            }
            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        Element elm = LstElements[i].MouseRangerAt(mp, angle);
                        if(LstElements[i] == elm)
                        {
                            LstElements.RemoveAt(i);
                            if (LstElements.Count == 0) LstElements = null;
                            return elm;
                        }
                    }
            }
            return null;
        }*/

        public override Element RangerVersParent(Element parent)
        {
            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        Element elm = (LstFigurines[i] as Element).RangerVersParent(parent);
                        if (LstFigurines[i] == elm)
                        {
                            LstFigurines.RemoveAt(i);
                            --i;
                        }
                    }
            }
            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        Element elm = LstElements[i].RangerVersParent(parent);
                        if (LstElements[i] == elm)
                        {
                            LstElements.RemoveAt(i);
                            --i;
                        }
                    }
            }
            return null;
        }

        public override Element DéfausserElement(Element relem)
        {
            if (LstFigurines != null)
            {
                for (int i = 0; i < LstFigurines.Count; ++i)
                    if (LstFigurines[i] != null)
                    {
                        Element elm = (LstFigurines[i] as Element).DéfausserElement(relem);
                        if (elm != null)
                        {
                            if (LstFigurines[i] == elm)
                                LstFigurines.RemoveAt(i);
                            return elm;
                        }
                        else if (LstFigurines[i] == relem)
                            return relem;
                    }
            }
            if (LstElements != null)
            {
                for (int i = 0; i < LstElements.Count; ++i)
                    if (LstElements[i] != null)
                    {
                        Element elm = LstElements[i].DéfausserElement(relem);
                        if (elm != null)
                        {
                            if (LstElements[i] == elm)
                                LstElements.RemoveAt(i);
                            return elm;
                        }
                        else if (LstElements[i] == relem)
                            return relem;
                    }
            }
            return null;
        }

        public override Element DétacherElement(Element relem)
        {
            Element belm;
            belm = base.DétacherElement(relem);
            if (belm != null) return belm;
            else 
            {
                if (LstFigurines != null)
                {
                    for (int i = 0; i < LstFigurines.Count; ++i)
                        if (LstFigurines[i] != null)
                        {
                            Element felm = (LstFigurines[i] as Element).DétacherElement(relem);
                            if (felm != null)
                            {
                                if (LstFigurines[i] == felm)
                                {
                                    LstFigurines.RemoveAt(i);
                                    if (LstFigurines.Count == 0) LstFigurines = null;
                                    if (felm is Paquet)
                                    {
                                        LstElements.Remove(felm);
                                        if (LstElements.Count == 0) LstElements = null;
                                    }
                                }
                                /*felm.GC.P.X += GC.P.X;
                                felm.GC.P.Y += GC.P.Y;
                                felm.GC.A += GC.A;*/
                                felm.GC.ProjectionInv(GC);
                                return felm;
                            }
                        }
                }

                if (LstElements != null)
                {
                    for (int i = 0; i < LstElements.Count; ++i)
                        if (LstElements[i] != null)
                        {
                            Element felm = LstElements[i].DétacherElement(relem);
                            if (felm != null)
                            {
                                if (LstElements[i] == felm)
                                {
                                    LstElements.RemoveAt(i);
                                    if (LstElements.Count == 0) LstElements = null;
                                }
                                /*felm.GC.P.X += GC.P.X;
                                felm.GC.P.Y += GC.P.Y;*/
                                felm.GC.ProjectionInv(GC);
                                return felm;
                            }
                        }
                }
                //if (LstFigurines != null)
                //{
                //    for (int i = 0; i < LstFigurines.Count; ++i)
                //        if (LstFigurines[i] != null)
                //        {
                //            elm = (LstFigurines[i] as Element).DétacherElement(relem);
                //            if (elm != null)
                //            {
                //                if (LstFigurines[i] == elm)
                //                    LstFigurines.RemoveAt(i);
                //                elm.GC.P.X += GC.P.X;
                //                elm.GC.P.Y += GC.P.Y;
                //                return elm;
                //            }
                //            else if (LstFigurines[i] == relem)
                //            {
                //                LstFigurines.RemoveAt(i);
                //                relem.GC.P.X += GC.P.X;
                //                relem.GC.P.Y += GC.P.Y;
                //                return relem;
                //            }
                //        }
                //}
                //if (LstElements != null)
                //{
                //    for (int i = 0; i < LstElements.Count; ++i)
                //        if (LstElements[i] != null)
                //        {
                //            elm = LstElements[i].DétacherElement(relem);
                //            if (elm != null)
                //            {
                //                if (LstElements[i] == elm)
                //                    LstElements.RemoveAt(i);
                //                elm.GC.P.X += GC.P.X;
                //                elm.GC.P.Y += GC.P.Y;
                //                return elm;
                //            }
                //            else if (LstElements[i] == relem)
                //            {
                //                LstElements.RemoveAt(i);
                //                relem.GC.P.X += GC.P.X;
                //                relem.GC.P.Y += GC.P.Y;
                //                return relem;
                //            }
                //        }
                //}
                return null;
            }
        }

        public override bool PutOnTop(Element elm)
        {
            if (LstElements != null)
            {
                for(int i = 0; i< LstElements.Count; ++i)
                    if (LstElements[i] != null && LstElements[i].PutOnTop(elm) && LstElements[i] == elm)
                    {
                        PutTop(i);
                        return true;
                    }
            }
            return false;
        }

        public override bool Lier(XmlNode paq, Dictionary<string, Element> dElements)
        {
            return _lier(paq.ChildNodes, dElements);
        }

        /// <summary>
        /// Mettre à jour l'élément numéro numElm par l'élément elm
        /// </summary>
        /// <param name="numElm"></param>
        /// <param name="elm"></param>
        /// <returns></returns>
        override public object MettreAJour(object obj)
        {
            if (obj is Element)
            {
                Element elm = obj as Element;
                if (elm.IdentifiantRéseau == IdentifiantRéseau) return elm;
                else
                {
                    object res = null;
                    for (int i = 0; res == null && i < LstElements.Count; ++i)
                    {
                        Element e = LstElements[i];
                        if (e != null)
                        {
                            res = e.MettreAJour(elm);
                            if (e == res) LstElements[i] = elm;
                        }
                    }
                    return res;
                }
            }
            else if (obj is Image)
            {
                Image img = obj as Image;
                if (LstElements != null)
                    LstElements.ForEach(e => e?.MettreAJour(img));
                return base.MettreAJour(obj);
            }
            else return base.MettreAJour(obj);
        }

        public override Element Suppression(Element elm)
        {
            Element re;
            re = base.Suppression(elm);
            if (re != null) return re;
            else
            {
                if (LstFigurines != null && LstFigurines.Count > 0)
                {
                    bool isOwn = false;
                    re = null;
                    foreach (Element e in LstFigurines)
                    {
                        re = e.Suppression(elm);
                        if (re != null)
                        {
                            isOwn = Object.ReferenceEquals(re, e);
                            break;
                        }
                        /*if(re == null) re = e.Suppression(elm);
                        else e.Suppression(elm);
                        if (re != null) return re;*/
                    }
                    if (re != null)
                    {
                        if (isOwn) LstFigurines.Remove(re as IFigurine);
                        return re;
                    }
                }
                if (LstElements != null && LstElements.Count > 0)
                {
                    bool isOwn = false;
                    re = null;
                    foreach (Element e in LstElements)
                    {
                        re = e.Suppression(elm);
                        if (re != null)
                        {
                            isOwn = Object.ReferenceEquals(re, e);
                            break;
                        }
                        /*if(re == null) re = e.Suppression(elm);
                        else e.Suppression(elm);
                        if (re != null) return re;*/
                    }
                    if (re != null)
                    {
                        if (isOwn) LstElements.Remove(re);
                        return re;
                    }
                }
                return null;
            }
        }

        public void Nétoyer()
        {
            if(LstElements != null)
            {
                LstElements.Clear();
                LstElements = null;
            }
            if (LstFigurines != null)
            {
                LstFigurines.Clear();
                LstFigurines = null;
            }
        }

        override public object Clone()
        {
            return new Groupe(this);
        }

        public override bool Equals(object obj)
        {
            return Object.ReferenceEquals(this, obj);
            /*if (Object.ReferenceEquals(this, obj)) return true;
            else if (obj is Groupe)
            {
                Groupe elm = obj as Groupe;
                if (LstFigurines != elm.LstFigurines && LstFigurines != null && elm.LstFigurines != null && LstFigurines.Count == elm.LstFigurines.Count)
                {
                    if (LstElements != null && elm.LstElements != null && LstElements.Count == elm.LstElements.Count)
                    {
                        foreach (IFigurine e in LstFigurines)
                            if (elm.LstFigurines.Contains(e) == false) return false;
                    }
                    else return false;
                }
                if (LstElements != elm.LstElements)
                {
                    if (LstElements != null && elm.LstElements != null && LstElements.Count == elm.LstElements.Count)
                    {
                        foreach (Element e in LstElements)
                            if (elm.LstElements.Contains(e) == false) return false;
                    }
                    else return false;
                }
                return true;
            }
            else return false;*/
        }


        public Groupe(Stream stream, IRessourcesDésérialiseur resscDes)
            : base(stream, resscDes)
        {
            /*
                private List<Element> LstElements = null;
                private List<IFigurine> LstFigurines = null;
            */
            Element elm;

            int nbe = stream.ReadInt();
            if (nbe > 0)
            {
                LstElements = new List<Element>(nbe);
                for (int i = 0; i < nbe; ++i)
                {
                    elm = resscDes.RetrouverObject(stream) as Element;
                    if (elm == null) throw new Exception("Désérialisation d'un groupe avec un élément vide !");
                    LstElements.Add(elm);
                }
            }
            else LstElements = null;
            elm = resscDes.RetrouverObject(stream) as Element;
            if (elm != null) throw new Exception("Désérialisation d'un groupe incorrecte !");
            nbe = stream.ReadInt();
            if (nbe > 0)
            {
                LstFigurines = new List<IFigurine>(nbe);
                for (int i = 0; i < nbe; ++i)
                {
                    elm = resscDes.RetrouverObject(stream) as Element;
                    if (elm == null) throw new Exception("Désérialisation d'un groupe avec un élément vide !");
                    LstFigurines.Add(elm as IFigurine);
                }
            }
            else LstFigurines = null;
            elm = resscDes.RetrouverObject(stream) as Element;
            if (elm != null) throw new Exception("Désérialisation d'un groupe incorrecte !");
        }

        override public void Serialiser(Stream stream, ref int gidr)
        {
            base.Serialiser(stream, ref gidr);
            /*
                private List<Element> LstElements = null;
                private List<IFigurine> LstFigurines = null;
            */
            stream.SerialiserObject(LstElements?.Count ?? 0);
            if (LstElements != null)
                foreach (Element e in LstElements) stream.SerialiserRefElement(e, ref gidr);
            stream.SerialiserObject(0);//Marque la fin
            stream.SerialiserObject(LstFigurines?.Count ?? 0);
            if (LstFigurines != null)
                foreach (Element e in LstFigurines) stream.SerialiserRefElement(e, ref gidr);
            stream.SerialiserObject(0);//Marque la fin
        }

        override public void SerialiserTout(Stream stream, ref int gidr, ISet<int> setIdRéseau)
        {
            if (LstElements != null)
                foreach (Element e in LstElements) stream.SerialiserTout(e, ref gidr, setIdRéseau);
            if (LstFigurines != null)
                foreach (Element e in LstFigurines) stream.SerialiserTout(e, ref gidr, setIdRéseau);
            base.SerialiserTout(stream, ref gidr, setIdRéseau);
        }
    }
}
