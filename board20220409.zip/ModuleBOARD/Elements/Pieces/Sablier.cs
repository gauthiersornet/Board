﻿using ModuleBOARD.Elements.Base;
using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace ModuleBOARD.Elements.Pieces
{
    public class Sablier : Element, IFigurine
    {
        private ushort Larg, Haut, Goulo;
        private Color CouleurContour, CouleurSable, CouleurVide;
        private uint Durée;
        private uint Ecoulé;
        private float LargGoulo;
        private PointF[] SablierCompletPts;
        private uint MsTempsDépart;

        public bool à_l_endroit { get => !EstDansEtat(EEtat.Retournée); set => AssignerEtat(EEtat.Retournée, !value); }
        public bool Couchée { get => EstDansEtat(EEtat.Couché); set => AssignerEtat(EEtat.Couché, value); }

        public override PointF Size => GC.ProjSize(new PointF(2 * Larg, 2 * Haut));

        public override EType ElmType { get => EType.Sablier; }

        public float Z { get; set; }

        public Sablier()
        {
            MettreEtat(EEtat.RotationFixe);

            Larg = 20;
            Haut = 80;
            Goulo = 20;
            Durée = 30 * 1000;
            GC.E /= 3;

            CouleurContour = Color.Black;
            CouleurSable = Color.White;
            CouleurVide = Color.FromArgb(32, Color.Cyan);

            RecalculerSablier();
            InitialiserTempsEcoulé(Durée);
        }

        public Sablier(Sablier sab)
            :base(sab)
        {
            MettreEtat(EEtat.RotationFixe);

            Larg = sab.Larg;
            Haut = sab.Haut;
            Goulo = sab.Goulo;

            CouleurContour = sab.CouleurContour;
            CouleurSable = sab.CouleurSable;
            CouleurVide = sab.CouleurVide;

            RecalculerSablier();
            InitialiserTempsEcoulé(Durée);
        }

        public Sablier(XmlNode paq, PointF p)
        {
            MettreEtat(EEtat.RotationFixe);

            Load(paq);
            GC.P.X += p.X;
            GC.P.Y += p.Y;
            GC.E /= 3;

            Larg = ushort.Parse((paq.Attributes.GetNamedItem("larg")?.Value ?? "20"));
            Haut = ushort.Parse((paq.Attributes.GetNamedItem("haut")?.Value ?? "80"));
            Goulo = ushort.Parse((paq.Attributes.GetNamedItem("goulo")?.Value ?? "20"));
            Durée = uint.Parse((paq.Attributes.GetNamedItem("durée")?.Value ?? "30")) * 1000;

            if (Goulo < 2) Goulo = 2;
             CouleurContour = Color.FromName((paq.Attributes.GetNamedItem("contour")?.Value ?? "Black").Trim());
            CouleurSable = Color.FromName((paq.Attributes.GetNamedItem("sable")?.Value ?? "White").Trim());

            string strCouleurVide = (paq.Attributes.GetNamedItem("vide")?.Value ?? "32/Cyan").Trim();
            string[] idxSplit = strCouleurVide.Split('/');
            int alpha;
            string colName;
            if (idxSplit.Length == 2)
            {
                alpha = int.Parse(idxSplit[0].TrimEnd());
                if (alpha > 128) alpha = 128;
                colName = idxSplit[1].TrimStart();
            }
            else
            {
                alpha = 32;
                colName = idxSplit[0].TrimStart();
            }
            CouleurVide = Color.FromArgb(alpha, Color.FromName(colName));

            RecalculerSablier();
            InitialiserTempsEcoulé(Durée);
        }

        private void RecalculerSablier()
        {
            LargGoulo = (1.5f * Larg) / 20;
            SablierCompletPts = new PointF[] {
                new PointF(Larg, Haut),   //0
                new PointF(Larg, Goulo),  //1
                new PointF(LargGoulo, 0.0f),  //2
                new PointF(Larg, -Goulo), //3
                new PointF(Larg, -Haut),  //4
                new PointF(-Larg, -Haut), //5
                new PointF(-Larg, -Goulo),//6
                new PointF(-LargGoulo, 0.0f), //7
                new PointF(-Larg, Goulo),//8
                new PointF(-Larg, Haut)  //9
            };
        }

        public void InitialiserTempsEcoulé(uint écoulé)
        {
            if (écoulé > Durée) écoulé = Durée;
            MsTempsDépart = ((uint)System.Environment.TickCount) - écoulé;
            Ecoulé = écoulé;
        }

        private void MajTempsEcoulé()
        {
            if (EstDansEtat(EEtat.Couché)) InitialiserTempsEcoulé(Ecoulé);
            else if (Ecoulé < Durée)
            {
                uint curEcoul = (((uint)System.Environment.TickCount) - MsTempsDépart);
                if (curEcoul >= Durée) Ecoulé = Durée;
                else Ecoulé = curEcoul;
            }
            else Ecoulé = Durée;
        }

        public override object Clone()
        {
            return new Sablier(this);
        }

        public override void Dessiner(ushort idJoueur, RectangleF vue, float angle, Graphics g, bool retourné = false)
        {
            float E = GC.E / (2 * Math.Min(Larg, Haut));
            Matrix m = g.Transform;

            g.TranslateTransform(GC.P.X, GC.P.Y);

            if (Couchée)
            {
                g.RotateTransform(90.0f - angle);
                g.ScaleTransform(E, E);
                g.TranslateTransform(-Larg, 0.0f);
                DessinerSablier(vue, g);
            }
            else
            {
                g.RotateTransform(-angle);
                g.ScaleTransform(E, E);
                g.TranslateTransform(0.0f, -Haut);
                DessinerSablier(vue, g);
            }

            g.Transform = m;
        }

        public void DessinerFigurine(ushort idJoueur, RectangleF vue, float angle, Graphics g)
        {
            Dessiner(idJoueur, vue, angle, g);
        }

        private void DessinerSablier(RectangleF vue, Graphics g)
        {
            Pen pn = new Pen(CouleurContour);
            Pen pnv = new Pen(CouleurVide);
            SolidBrush brshExt = new SolidBrush(CouleurContour);
            SolidBrush brsh = new SolidBrush(CouleurSable);

            RectangleF elpInt = new RectangleF(-Larg + 0.5f, - 5 + 0.5f, 2 * Larg - 1.0f, 10 - 1.0f);
            RectangleF sabExt = new RectangleF(-Larg - 5f, Haut - 10, 2 * Larg + 10, 20);
            g.FillEllipse(brshExt, sabExt);

            MajTempsEcoulé();
            if (Ecoulé > 100)
            {
                float nivEcl = (((ulong)Ecoulé * (ulong)(Haut - Goulo)) / (float)Durée);
                g.FillPie(brsh, elpInt.X, Haut + elpInt.Y, elpInt.Width, elpInt.Height, 0.0f, 180.0f);
                g.FillPie(brsh, elpInt.X, Haut + elpInt.Y - nivEcl, elpInt.Width, elpInt.Height, 180.0f, 180.0f);
                g.FillRectangle(brsh, SablierCompletPts[9].X, SablierCompletPts[9].Y - nivEcl, 2 *Larg, nivEcl);
                g.DrawEllipse(pnv, elpInt.X, Haut + elpInt.Y - nivEcl, elpInt.Width, elpInt.Height);
            }

            if (Ecoulé < Durée)
            {
                float nivEcl = (((ulong)(Durée - Ecoulé) * (ulong)(Haut - Goulo)) / (float)Durée);
                if (nivEcl > Goulo)
                {
                    g.FillPolygon(brsh, new PointF[] { SablierCompletPts[2], SablierCompletPts[3], SablierCompletPts[6], SablierCompletPts[7] });
                    nivEcl -= Goulo;
                    g.FillRectangle(brsh, SablierCompletPts[6].X, SablierCompletPts[6].Y - nivEcl, 2 * Larg, nivEcl);
                    g.DrawEllipse(pnv, elpInt.X, -Goulo + elpInt.Y - nivEcl, elpInt.Width, elpInt.Height);
                    g.FillPie(brsh, elpInt.X, -Goulo + elpInt.Y - nivEcl, elpInt.Width, elpInt.Height, 180.0f, 180.0f);
                }
                else
                {
                    double ratio = (double)nivEcl / (double)Goulo;
                    float dtX = (float)(LargGoulo + (Larg - LargGoulo) * ratio);
                    g.FillPolygon(brsh, new PointF[] { SablierCompletPts[2], new PointF(dtX, - nivEcl), new PointF(-dtX, -nivEcl), SablierCompletPts[7] });
                    g.DrawEllipse(pnv, -dtX + 0.5f, + (float)(ratio * elpInt.Y) - nivEcl, 2 * (dtX - 0.5f), (float)(ratio * elpInt.Height));
                    g.FillPie(brsh, -dtX + 0.5f, +(float)(ratio * elpInt.Y) - nivEcl, 2 * (dtX - 0.5f), (float)(ratio * elpInt.Height), 180.0f, 180.0f);
                }
            }

            //g.DrawEllipse(pnv, elpInt.X, 0.5f * Goulo + elpInt.Y, elpInt.Width, elpInt.Height);
            //g.DrawEllipse(pnv, -LargGoulo, -1.0f, 2 * LargGoulo, 2.0f);
            //g.DrawEllipse(pnv, elpInt.X, -0.5f * Goulo + elpInt.Y, elpInt.Width, elpInt.Height);

            brsh = new SolidBrush(CouleurVide);
            g.FillPolygon(brsh, SablierCompletPts);
            g.FillPie(brsh, elpInt.X, Haut + elpInt.Y, elpInt.Width, elpInt.Height, 0.0f, 180.0f);
            g.DrawLines(pn, SablierCompletPts);
            //g.DrawArc(pn, elpInt.X, 0.5f * Haut + elpInt.Y, elpInt.Width, elpInt.Height, 0.0f, 180.0f);
            sabExt.Y = -sabExt.Y;
            sabExt.Height = -sabExt.Height;
            g.FillEllipse(brshExt, sabExt);
        }

        public override bool Lier(XmlNode paq, Dictionary<string, Element> dElements)
        {
            return true;
        }

        public override bool PutOnTop(Element elm)
        {
            return (this == elm);
        }

        override public bool IsAt(PointF mp, PointF psz, float angle)
        {
            mp.X -= GC.P.X/* - (psz.X / 2.0f)*/;
            mp.Y -= GC.P.Y/* - (psz.Y / 2.0f)*/;

            Matrix m = new Matrix();
            if (Couchée) m.Rotate(90.0f - angle);
            else m.Rotate(-angle);
            PointF nmp = new PointF
                (
                    mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                    mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                );

            if (Couchée)
            {
                psz.Y /= 2.0f;
                return (-psz.X <= nmp.X && -psz.Y <= nmp.Y && nmp.X <= 0.0f && nmp.Y <= psz.Y);
            }
            else
            {
                psz.X /= 2.0f;
                return (-psz.X <= nmp.X && -psz.Y <= nmp.Y && nmp.X <= psz.X && nmp.Y <= 0);
            }
        }

        override public void MajEtat(EEtat nouvEtat)
        {
            MajTempsEcoulé();
            if(AEtatChangé(EEtat.Retournée, nouvEtat)) InitialiserTempsEcoulé(Durée - Ecoulé);
            base.MajEtat(nouvEtat);
        }

        public override (Element, Element) MousePickAvecContAt(PointF mp, float angle, ushort idJr, EPickUpAction action)
        {
            if (action.HasFlag(EPickUpAction.Roulette)) action |= EPickUpAction.Tourner;
            return base.MousePickAvecContAt(mp, angle, idJr, action);
        }

        public override Element MousePickAt(PointF mp, float angle, ushort idJr, EPickUpAction action)
        {
            if (action.HasFlag(EPickUpAction.Roulette)) action |= EPickUpAction.Tourner;
            return base.MousePickAt(mp, angle, idJr, action);
        }

        override public ContextMenu Menu(IBoard ctrl, Joueur jr, Element elmRt)
        {
            ContextMenu cm = base.Menu(ctrl, jr, elmRt);
            if (cm == null) cm = new ContextMenu();

            if(Etat.HasFlag(Element.EEtat.Couché)) cm.MenuItems.Add(0, new MenuItem("Remettre", new EventHandler((o, e) => { ctrl.ChangerEtatElément(jr, elmRt, this, Etat ^ Element.EEtat.Couché); })));
            else cm.MenuItems.Add(0, new MenuItem("Arréter", new EventHandler((o, e) => { ctrl.ChangerEtatElément(jr, elmRt, this, Etat ^ Element.EEtat.Couché); })));
            cm.MenuItems.Add(1, new MenuItem("-"));
            cm.MenuItems.Add(2, new MenuItem("Réinitialiser", new EventHandler((o, e) => { ctrl.InitialiserTempsEcoulé(jr, elmRt, this, Durée); })));

            cm.MenuItems.AddRange(new MenuItem[]
                    {
                        new MenuItem("Mettre en paquet", new EventHandler((o,e) => {ctrl.MettreEnPaquet(jr, elmRt, this); ctrl.Refresh(); })),
                    });
            return cm;
        }

        public Sablier(Stream stream, IRessourcesDésérialiseur resscDes)
            : base(stream, resscDes)
        {
            Larg = stream.ReadUShort();
            Haut = stream.ReadUShort();
            Goulo = stream.ReadUShort();
            if (Goulo < 2) Goulo = 2;
            CouleurContour = stream.ReadColor();
            CouleurSable = stream.ReadColor();
            CouleurVide = stream.ReadColor();
            if (CouleurVide.A > 128) CouleurVide = Color.FromArgb(128, CouleurVide);
             Durée = stream.ReadUInt();
            Ecoulé = stream.ReadUInt();
            RecalculerSablier();
            InitialiserTempsEcoulé(Ecoulé);
        }

        override public void Serialiser(Stream stream, ref int gidr)
        {
            base.Serialiser(stream, ref gidr);
            stream.WriteUShort(Larg);
            stream.WriteUShort(Haut);
            stream.WriteUShort(Goulo);
            stream.WriteColor(CouleurContour);
            stream.WriteColor(CouleurSable);
            stream.WriteColor(CouleurVide);
            stream.WriteUInt(Durée);
            MajTempsEcoulé();
            stream.WriteUInt(Ecoulé);
        }

        override public void SerialiserTout(Stream stream, ref int gidr, ISet<int> setIdRéseau)
        {
            base.SerialiserTout(stream, ref gidr, setIdRéseau);
        }
    }
}
