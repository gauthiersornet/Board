﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base.Graphiques.SVG
{
    public class SVGPolygone : Graphique
    {
        private PointF[] pts;
        private Color contour;
        private Color remplissage;
        private float épaisseur;

        override public GType GraphType { get => GType.polygone; }

        public override Size Size => new Size((int)pts.Max(p => Math.Abs(p.X)), (int)pts.Max(p => Math.Abs(p.Y)));

        public override SizeF SizeF => new SizeF(pts.Max(p => Math.Abs(p.X)), pts.Max(p => Math.Abs(p.Y)));

        public override (PointF, PointF) MinMax
        {
            get
            {
                if (pts.Any())
                {
                    PointF min = new PointF(float.MaxValue, float.MaxValue);
                    PointF max = new PointF(float.MinValue, float.MinValue);
                    foreach (PointF p in pts)
                    {
                        min.X = Math.Min(min.X, p.X);
                        min.Y = Math.Min(min.Y, p.Y);
                        max.X = Math.Max(max.X, p.X);
                        max.Y = Math.Max(max.Y, p.Y);
                    }
                    return (min, max);
                }
                else return (new PointF(), new PointF());
            }
        }

        public SVGPolygone()
        {
        }

        public SVGPolygone(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
        {
            //<polygon points="50 160 55 180 70 180 60 190 65 205 50 195 35 205 40 190 30 180 45 180" stroke = "green" fill = "transparent" stroke - width = "5" />
            contour = Color.FromName(paq.Attributes.GetNamedItem("stroke")?.Value ?? "Transparent");
            remplissage = Color.FromName(paq.Attributes.GetNamedItem("fill")?.Value ?? "Transparent");
            épaisseur = float.Parse(paq.Attributes.GetNamedItem("stroke-width")?.Value ?? "1");
            string[] spts = paq.Attributes.GetNamedItem("points").Value.Replace("  ", " ").Trim().Split(' ');
            pts = new PointF[spts.Length / 2];
            for (int i = 0; i < pts.Length; ++i) pts[i] = new PointF(float.Parse(spts[2 * i]), float.Parse(spts[2 * i + 1]));

            float contourOpacité = float.Parse(paq.Attributes.GetNamedItem("stroke-opacity")?.Value ?? "1");
            if (contourOpacité < 1.0f) contour = Color.FromArgb((byte)(255.0 * contourOpacité + 0.5f), contour);
            float remplissageOpacité = float.Parse(paq.Attributes.GetNamedItem("fill-opacity")?.Value ?? "1");
            if (remplissageOpacité < 1.0f) remplissage = Color.FromArgb((byte)(255.0 * remplissageOpacité + 0.5f), remplissage);
        }

        public override void Centrer(PointF ctr)
        {
            if (pts != null) for (int i = 0; i < pts.Length; ++i)
                {
                    pts[i].X -= ctr.X;
                    pts[i].Y -= ctr.Y;
                }
        }

        public override void Dessiner(Graphics g, bool Retournée)
        {
            if (Retournée)
            {
                Matrix m = g.Transform;
                g.ScaleTransform(-1.0f, 1.0f);
                if (remplissage != Color.Transparent) g.FillPolygon(new SolidBrush(remplissage), pts);
                if (contour != Color.Transparent && épaisseur > 0.0f) g.DrawPolygon(new Pen(contour, épaisseur), pts);
                g.Transform = m;
            }
            else
            {
                if (remplissage != Color.Transparent) g.FillPolygon(new SolidBrush(remplissage), pts);
                if (contour != Color.Transparent && épaisseur > 0.0f) g.DrawPolygon(new Pen(contour, épaisseur), pts);
            }
        }

        public override void MettreAJour(object obj) { }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(contour);
            stream.SerialiserObject(remplissage);
            stream.SerialiserObject(épaisseur);
            stream.SerialiserObject(pts);
        }

        public SVGPolygone(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            contour = (Color)stream.DésérialiserObject(typeof(Color));
            remplissage = (Color)stream.DésérialiserObject(typeof(Color));
            épaisseur = (float)stream.DésérialiserObject(typeof(float));
            pts = (PointF[])stream.DésérialiserObject(typeof(PointF[]));
        }
    }
}
