﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;

namespace ModuleBOARD.Elements.Base.Graphiques.SVG
{
    public class SVGAltéré : Graphique
    {
        private Graphique graphique;
        public List<Graphique> Dessus;
        public List<Graphique> Dessous;

        public SVGAltéré()
        {
            Dessus = default;
            Dessous = default;
        }

        /*public SVGDouble(string path, XmlNode xmlnDessus, XmlNode xmlnDessous, PointF pZero, BibliothèqueImage bibliothèqueImage)
        {
            Dessus = dessus;
            Dessous = dessous;
        }*/

        override public GType GraphType { get => GType.Alteration; }
        override public object GraphiqueDessus { get => Dessus; }
        override public object GraphiqueDessous { get => Dessous; }

        override public void Centrer(PointF ctr)
        {
            graphique.Centrer(ctr);
            if (Dessus != null) Dessus.ForEach(d => d.Centrer(ctr));
            if (Dessous != null) Dessous.ForEach(d => d.Centrer(ctr));
        }

        override public Size Size { get => graphique.Size; }
        override public SizeF SizeF { get => graphique.SizeF; }

        public override (PointF, PointF) MinMax { get => graphique.MinMax; }

        override public void Dessiner(Graphics g, bool Retournée)
        {
            graphique.Dessiner(g, Retournée);
            List<Graphique> img = Retournée ? Dessous : Dessus;
            if (img != null) img.ForEach(d => d.Dessiner(g, false));
            {
                SizeF taille = graphique.SizeF;
                RectangleF dRect = new RectangleF(-taille.Width / 2, -taille.Height / 2, taille.Width, taille.Height);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
            }
        }


        override public void MettreAJour(object obj)
        {
            if (Dessus != null) Dessus.ForEach(d => d.MettreAJour(obj));
            if (Dessous != null) Dessous.ForEach(d => d.MettreAJour(obj));
        }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            Graphique.Serialiser(graphique, stream);
            ushort nbc = (ushort)(Dessus?.Count ?? 0);
            stream.WriteBytes(BitConverter.GetBytes(nbc));
            for (ushort i = 0; i < nbc; ++i)
            {
                Graphique.Serialiser(Dessus[i], stream, null);
            }
            nbc = (ushort)(Dessous?.Count ?? 0);
            stream.WriteBytes(BitConverter.GetBytes(nbc));
            for (ushort i = 0; i < nbc; ++i)
            {
                Graphique.Serialiser(Dessous[i], stream, null);
            }
        }

        public SVGAltéré(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            graphique = resscDes.RécupérerGraphique(stream, null);

            ushort nbc = BitConverter.ToUInt16(stream.GetBytes(2), 0);
            if (nbc > 0)
            {
                Dessus = new List<Graphique>(nbc);
                for (ushort i = 0; i < nbc; ++i)
                    Dessus.Add(resscDes.RécupérerGraphique(stream, null));
            }
            else Dessus = null;

            nbc = BitConverter.ToUInt16(stream.GetBytes(2), 0);
            if (nbc > 0)
            {
                Dessous = new List<Graphique>(nbc);
                for (ushort i = 0; i < nbc; ++i)
                    Dessous.Add(resscDes.RécupérerGraphique(stream, null));
            }
            else Dessous = null;
        }

        /*public override bool Equals(object obj)
        {
            if (base.Equals(obj)) return true;
            else if (obj is SVGDouble) return ((obj as SVGDouble).Dessus == Dessus && (obj as SVGDouble).Dessous == Dessous);
            else return false;
        }*/

        /*public override int GetHashCode()
        {
            return (Dessus?.GetHashCode() ?? 0) + (Dessous?.GetHashCode() ?? 0);
        }*/
    }
}
