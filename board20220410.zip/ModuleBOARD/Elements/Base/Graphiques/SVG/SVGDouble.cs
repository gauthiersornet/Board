﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Xml;
using ModuleBOARD.Réseau;

namespace ModuleBOARD.Elements.Base.Graphiques
{
    public class SVGDouble : Graphique
    {
        private SizeF taille;
        public List<Graphique> Dessus;
        public List<Graphique> Dessous;

        public override (PointF, PointF) MinMax { get => (new PointF(-taille.Width / 2.0f, -taille.Height / 2.0f), new PointF(taille.Width / 2.0f, taille.Height / 2.0f)); }

        public SVGDouble()
        {
            Dessus = default;
            Dessous = default;
        }

        /*public SVGDouble(string path, XmlNode xmlnDessus, XmlNode xmlnDessous, PointF pZero, BibliothèqueImage bibliothèqueImage)
        {
            Dessus = dessus;
            Dessous = dessous;
        }*/

        public SVGDouble(string chmImg, XmlNode xmln, BibliothèqueImage bibliothèqueImage)
        {
            Dessus = default;
            Dessous = default;
            foreach (XmlNode nd in xmln)
            {
                string itmNm = nd.Name.Trim().ToUpper();
                if (nd.Name == "DESSUS") Dessus = ChargerSVG(chmImg, xmln, bibliothèqueImage);
                else if (nd.Name == "DESSOUS") Dessous = ChargerSVG(chmImg, xmln, bibliothèqueImage);
            }
            SizeF szDessus = Graphique.CentrerEtDimensionner(Dessus);
            SizeF szDessous = Graphique.CentrerEtDimensionner(Dessous);
            taille = new SizeF(Math.Max(szDessus.Width, szDessous.Width), Math.Max(szDessus.Height, szDessous.Height));
        }

        public SVGDouble(List<Graphique> dessus, List<Graphique> dessous)
        {
            Dessus = dessus;
            Dessous = dessous;
            SizeF szDessus = Graphique.CentrerEtDimensionner(Dessus);
            SizeF szDessous = Graphique.CentrerEtDimensionner(Dessous);
            taille = new SizeF(Math.Max(szDessus.Width, szDessous.Width), Math.Max(szDessus.Height, szDessous.Height));
        }

        override public GType GraphType { get => GType.SVGDouble; }
        override public object GraphiqueDessus { get => Dessus; }
        override public object GraphiqueDessous { get => Dessous; }

        override public void Centrer(PointF ctr)
        {
            if (Dessus != null) Dessus.ForEach(d => d.Centrer(ctr));
            if (Dessous != null) Dessous.ForEach(d => d.Centrer(ctr));
        }

        override public Size Size { get => new Size((int)taille.Width, (int)taille.Height); }
        override public SizeF SizeF { get => taille; }

        /*override public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, RectangleF dRect, bool Retournée)
        {
            Matrix res;
            List<Graphique> img = Retournée ? Dessous: Dessus;

            if (img != null)
            {
                float sclRatio = GC.E / Math.Min(taille.Width, taille.Height);
                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                //g.DrawImage(img, dRect);
                img.ForEach(d => d.Dessiner(vue, g, GC, false));
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);

            return res;
        }*/

        /*override public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, bool Retournée)
        {
            Matrix res;

            List<Graphique> img = Retournée ? Dessous : Dessus;

            if (img != null)
            {
                float sclRatio = GC.E / Math.Min(taille.Width, taille.Height);
                RectangleF dRect = new RectangleF(-taille.Width / 2, -taille.Height / 2, taille.Width, taille.Height);

                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                if(Retournée) g.ScaleTransform(-sclRatio, sclRatio);
                else g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                //g.DrawImage(img, dRect);
                img.ForEach(d => d.Dessiner(vue, g, GC, false));
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);

            return res;
        }*/

        override public void Dessiner(Graphics g, bool Retournée)
        {
            List<Graphique> img = Retournée ? Dessous : Dessus;
            if (img != null)img.ForEach(d => d.Dessiner(g, false));
            else
            {
                RectangleF dRect = new RectangleF(-taille.Width / 2, -taille.Height / 2, taille.Width, taille.Height);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
            }
        }

        /*override public Matrix DessinerVide(RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;

            if (taille.Width > 0 && taille.Height > 0)
            {
                float sclRatio = Math.Min(taille.Width, taille.Height);
                RectangleF dRect = new RectangleF(-taille.Width / 2, -taille.Height / 2, taille.Width, taille.Height);

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);
            return res;
        }*/

        override public void MettreAJour(object obj)
        {
            if (Dessus != null) Dessus.ForEach(d => d.MettreAJour(obj));
            if (Dessous != null) Dessous.ForEach(d => d.MettreAJour(obj));
        }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(taille);
            ushort nbc = (ushort)(Dessus?.Count ?? 0);
            stream.WriteBytes(BitConverter.GetBytes(nbc));
            for (ushort i = 0; i < nbc; ++i)
            {
                Graphique.Serialiser(Dessus[i], stream, vide);
            }
            nbc = (ushort)(Dessous?.Count ?? 0);
            stream.WriteBytes(BitConverter.GetBytes(nbc));
            for (ushort i = 0; i < nbc; ++i)
            {
                Graphique.Serialiser(Dessous[i], stream, vide);
            }
        }

        public SVGDouble(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            taille = (SizeF)stream.DésérialiserObject(typeof(SizeF));

            ushort nbc = BitConverter.ToUInt16(stream.GetBytes(2), 0);
            if (nbc > 0)
            {
                Dessus = new List<Graphique>(nbc);
                for (ushort i = 0; i < nbc; ++i)
                    Dessus.Add(resscDes.RécupérerGraphique(stream, vide));
            }
            else Dessus = null;

            nbc = BitConverter.ToUInt16(stream.GetBytes(2), 0);
            if (nbc > 0)
            {
                Dessous = new List<Graphique>(nbc);
                for (ushort i = 0; i < nbc; ++i)
                    Dessous.Add(resscDes.RécupérerGraphique(stream, vide));
            }
            else Dessous = null;
        }

        /*public override bool Equals(object obj)
        {
            if (base.Equals(obj)) return true;
            else if (obj is SVGDouble) return ((obj as SVGDouble).Dessus == Dessus && (obj as SVGDouble).Dessous == Dessous);
            else return false;
        }*/

        /*public override int GetHashCode()
        {
            return (Dessus?.GetHashCode() ?? 0) + (Dessous?.GetHashCode() ?? 0);
        }*/
    }
}
