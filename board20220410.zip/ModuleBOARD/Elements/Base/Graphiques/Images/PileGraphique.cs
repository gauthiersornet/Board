﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;

namespace ModuleBOARD.Elements.Base.Graphiques.Images
{
    public class PileGraphique : Graphique
    {
        private SizeF taille;
        private List<Graphique> Pile;

        public PileGraphique(List<Graphique> pile)
        {
            Pile = pile;
        }

        override public GType GraphType { get => GType.ImageSimple; }
        override public object GraphiqueDessus { get => Pile; }
        override public object GraphiqueDessous { get => Pile; }

        override public void Centrer(PointF ctr) { if (Pile != null) Pile.ForEach(d => d.Centrer(ctr)); }

        override public Size Size { get => new Size((int)taille.Width, (int)taille.Height); }
        override public SizeF SizeF { get => taille; }
        override public void Dessiner(Graphics g, bool Retournée)
        {
            if (Pile != null)
            {
                if (Retournée) for (int i = Pile.Count - 1; i >= 0; --i) Pile[i].Dessiner(g, Retournée);
                else Pile.ForEach(d => d.Dessiner(g, Retournée));
            }
            else
            {
                RectangleF dRect = new RectangleF(-taille.Width / 2, -taille.Height / 2, taille.Width, taille.Height);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
            }
        }

        override public void MettreAJour(object obj)
        {
            if (Pile != null) Pile.ForEach(d => d.MettreAJour(obj));
        }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            ushort nbc = (ushort)(Pile?.Count ?? 0);
            stream.WriteBytes(BitConverter.GetBytes(nbc));
            for (ushort i = 0; i < nbc; ++i)
            {
                Graphique.Serialiser(Pile[i], stream, null);
            }
        }

        public PileGraphique(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            ushort nbc = BitConverter.ToUInt16(stream.GetBytes(2), 0);
            if (nbc > 0)
            {
                Pile = new List<Graphique>(nbc);
                for (ushort i = 0; i < nbc; ++i)
                    Pile.Add(resscDes.RécupérerGraphique(stream, null));
            }
            else Pile = null;
        }
    }
}
