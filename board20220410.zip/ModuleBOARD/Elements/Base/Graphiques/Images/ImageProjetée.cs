﻿using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base.Graphiques
{
    public class ImageProjetée : Graphique
    {
        private Image Dessus;
        private RectangleF Projection;
        private float angle;

        public override (PointF, PointF) MinMax
        {
            get
            {
                if (angle == 0.0f) return (new PointF(Projection.X, Projection.Y), new PointF(Projection.X + Projection.Width, Projection.Y + Projection.Height));
                else
                {
                    Matrix m = new Matrix();
                    m.Rotate(angle);
                    PointF rp = new PointF
                        (
                            Projection.X * m.Elements[0] + Projection.Y * m.Elements[1],
                            Projection.X * m.Elements[2] + Projection.Y * m.Elements[3]
                        );
                    PointF vecX = new PointF
                        (
                            Projection.Width * m.Elements[0],
                            Projection.Width * m.Elements[2]
                        );
                    PointF vecY = new PointF
                        (
                            Projection.Height * m.Elements[1],
                            Projection.Height * m.Elements[3]
                        );
                    PointF min = new PointF(Projection.X, Projection.Y);
                    PointF max = min;
                    PointF v = new PointF(Projection.X + vecX.X, Projection.Y + vecX.Y);
                    min.X = Math.Min(min.X, v.X); max.X = Math.Max(max.X, v.X);
                    min.Y = Math.Min(min.Y, v.Y); max.Y = Math.Max(max.Y, v.Y);
                    v = new PointF(v.X + vecY.X, v.Y + vecY.Y);
                    min.X = Math.Min(min.X, v.X); max.X = Math.Max(max.X, v.X);
                    min.Y = Math.Min(min.Y, v.Y); max.Y = Math.Max(max.Y, v.Y);
                    v = new PointF(Projection.X + vecY.X, Projection.Y + vecY.Y);
                    min.X = Math.Min(min.X, v.X); max.X = Math.Max(max.X, v.X);
                    min.Y = Math.Min(min.Y, v.Y); max.Y = Math.Max(max.Y, v.Y);
                    return (new PointF(Projection.X + Projection.Width, Projection.Y + Projection.Height), new PointF(Projection.X + Projection.Width, Projection.Y + Projection.Height));
                }
            }
        }

        public ImageProjetée()
        {
            Dessus = default;
        }

        public ImageProjetée(Image img)
        {
            Dessus = img;
        }

        override public GType GraphType { get => GType.ImageProjetée; }

        override public object GraphiqueDessus { get => Dessus; }
        override public object GraphiqueDessous { get => Dessus; }

        override public void Centrer(PointF ctr) { }

        override public Size Size { get { return new Size((int)(2 * Math.Max(Math.Abs(Projection.X - Projection.Width / 2.0f), Math.Abs(Projection.X + Projection.Width / 2.0f))), (int)(2 * Math.Max(Math.Abs(Projection.Y - Projection.Height / 2.0f), Math.Abs(Projection.Y + Projection.Height / 2.0f)))); } }
        override public SizeF SizeF { get { return new SizeF((2.0f * Math.Max(Math.Abs(Projection.X - Projection.Width / 2.0f), Math.Abs(Projection.X + Projection.Width / 2.0f))), (2.0f * Math.Max(Math.Abs(Projection.Y - Projection.Height / 2.0f), Math.Abs(Projection.Y + Projection.Height / 2.0f)))); } }

        public ImageProjetée(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
        {
            //<image img="pingouis.jpg" x="0" y="0" height="50px" width="50px"/>
            string fileDessus = paq.Attributes.GetNamedItem("img").Value;
            Dessus = bibliothèqueImage.ChargerSImage(path, fileDessus, paq, "ix", "iy", "iw", "ih");

            string swidth = paq.Attributes.GetNamedItem("width")?.Value?.Trim();
            string sheight = paq.Attributes.GetNamedItem("height")?.Value?.Trim();

            if (swidth != null && swidth.EndsWith("pt")) swidth = swidth.Substring(0, swidth.Length - 2);
            if (sheight != null && sheight.EndsWith("pt")) sheight = sheight.Substring(0, sheight.Length - 2);

            float width, height;
            if (string.IsNullOrWhiteSpace(swidth)) width = Dessus.Width;
            else width = float.Parse(swidth);
            if (string.IsNullOrWhiteSpace(sheight)) height = Dessus.Height;
            else height = float.Parse(sheight); 

            string sx = paq.Attributes.GetNamedItem("x")?.Value;
            string sy = paq.Attributes.GetNamedItem("y")?.Value;

            string strCentrer = paq.Attributes.GetNamedItem("center")?.Value?.Trim().ToLower() ?? "";

            float x, y;
            if (string.IsNullOrWhiteSpace(sx))
            {
                x = -width / 2.0f;
                if (strCentrer.Contains("left"))
                {
                    //centrer |= ECentrer.Gauche;
                    x += width / 2.0f;
                }
                if (strCentrer.Contains("right"))
                {
                    //centrer |= ECentrer.Droite;
                    x -= width / 2.0f;
                }
            }
            else x = float.Parse(sx);
            if (string.IsNullOrWhiteSpace(sy))
            {
                y = -height / 2.0f;
                if (strCentrer.Contains("top") || strCentrer.Contains("up"))
                {
                    //centrer |= ECentrer.Haut;
                    y += height / 2.0f;
                }
                if (strCentrer.Contains("bottom") || strCentrer.Contains("down"))
                {
                    //centrer |= ECentrer.Bas;
                    y -= height / 2.0f;
                }
            }
            else y = float.Parse(sy);

            float angle = float.Parse(paq.Attributes.GetNamedItem("rotation")?.Value ?? "0");

            Projection = new RectangleF(x, y, width, height);
        }

        override public void Dessiner(Graphics g, bool Retournée)
        {
            if (Dessus != null)
            {
                if (Retournée)
                {
                    Matrix m = g.Transform;
                    g.ScaleTransform(-1.0f, 1.0f);
                    if(angle != 0.0f)g.RotateTransform(angle);
                    g.DrawImage(Dessus, Projection);
                    g.Transform = m;
                }
                else g.DrawImage(Dessus, Projection);
            }
            else g.FillRectangle(new SolidBrush(Color.Gray), Projection);
        }

        override public void MettreAJour(object obj)
        {
            if (obj is Image)
            {
                Image img = obj as Image;
                if (Dessus != null && String.Equals(Dessus.Tag as string, img.Tag as string))
                    Dessus = img;
            }
        }

        override public void Serialiser(Stream stream, Graphique vide = null)
        {
            base.Serialiser(stream, vide);
            stream.SerialiserObject(angle);
            if (vide != null && vide.GraphiqueDessus == Dessus) stream.WriteByte(0);
            else stream.SerialiserImage(Dessus);
        }

        public ImageProjetée(Stream stream, IRessourcesDésérialiseur resscDes, Graphique vide)
        {
            angle = (float)stream.DésérialiserObject(typeof(float));
            Dessus = resscDes.RécupérerImage(stream);
            if (Dessus == null) Dessus = vide?.GraphiqueDessus as Image;
        }

        public override bool Equals(object obj)
        {
            if (base.Equals(obj)) return true;
            else if (obj is ImageSimple) return (obj as ImageProjetée).Dessus == Dessus && (obj as ImageProjetée).Projection == Projection;
            else return false;
        }

        public override int GetHashCode()
        {
            return (Dessus?.GetHashCode() ?? 0);
        }
    }
}
