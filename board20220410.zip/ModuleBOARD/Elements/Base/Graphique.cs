﻿using ModuleBOARD.Elements.Base.Graphiques;
using ModuleBOARD.Elements.Base.Graphiques.SVG;
using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml;

namespace ModuleBOARD.Elements.Base
{
    public abstract class Graphique : ICloneable
    {
        public enum GType : byte
        {
            Vide = 0,

            ImageSimple,
            ImageDouble, //Recto et verso

            SVGSimple,
            SVGDouble, //Recto et verso

            ImageSVG, // Dessus/Dos = image et Dessous = svg

            //NGraphique,//Empillement de N graphique
            Alteration, //Contient un graphique générique avec 2 SVG représentant les modifications

            line,
            polyline,
            rect,
            circle,
            polygone,
            text,
            ImageProjetée
        }

        static public readonly Type[] GTypeT =
        {
            null,
            typeof(ImageSimple),
            typeof(ImageDouble),
            typeof(SVGSimple),
            typeof(SVGDouble),
            typeof(ImageProjetée),//ImageSVG
            //null,//NGraphique
            typeof(SVGAltéré),//Alteration
            typeof(SVGLine),
            typeof(SVGPolyline),
            typeof(SVGRect),
            typeof(SVGCicrle),
            typeof(SVGPolygone),
            typeof(SVGText),
            typeof(ImageProjetée)
        };

        static public Graphique Charger(string chmImg, string nomImg, BibliothèqueImage bibliothèqueImage)
        {
            if (nomImg.Substring(nomImg.Length - 4, 4).ToUpper().EndsWith(".SVG"))
            {
                return new SVGSimple(chmImg, nomImg, bibliothèqueImage);
            }
            else return new ImageSimple(bibliothèqueImage.ChargerImage(chmImg, nomImg));
        }

        static public Matrix DessinerVide(Point img, RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            if (img.X > 0 && img.Y > 0)
            {
                float sclRatio = Math.Min(img.X, img.Y);
                RectangleF dRect = new RectangleF(-img.X / 2, -img.Y / 2, img.X, img.Y);

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = null;
            return res;
        }


        static public Matrix DessinerVide(RectangleF dRect, RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            if (dRect.Width > 0 && dRect.Height > 0)
            {
                float sclRatio = Math.Min(dRect.Width, dRect.Height);
                if (sclRatio < 0.0f) sclRatio = -sclRatio;

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = null;
            return res;
        }

        static public void DessinerVide(Point img, Graphics g)
        {
            RectangleF dRect = new RectangleF(-img.X / 2, -img.Y / 2, img.X, img.Y);
            g.FillRectangle(new SolidBrush(Color.Gray), dRect);
        }

        static public void DessinerVide(RectangleF dRect, Graphics g)
        {
            g.FillRectangle(new SolidBrush(Color.Gray), dRect);
        }

        static public List<Graphique> ChargerSVG(string chmImg, XmlNode xmln, BibliothèqueImage bibliothèqueImage)
        {
            List<Graphique> grphs = new List<Graphique>();
            //return ChargerSVG(chmImg, xmln, bibliothèqueImage);
            string[] svgKeywrd = Enum.GetNames(typeof(GType));
            int idx;
            for (idx = 0; idx < svgKeywrd.Length && !svgKeywrd[idx].Equals(xmln.Name); ++idx) ;
            if (idx < svgKeywrd.Length)
            {
                Type gTypT = Graphique.GTypeT[idx];
                //public svg(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
                ConstructorInfo cstr = gTypT.GetConstructor(new Type[] { typeof(string), typeof(XmlNode), typeof(BibliothèqueImage) });
                if (cstr != null)
                {
                    /*try
                    {*/
                    Graphique grph = cstr.Invoke(new object[] { chmImg, xmln, bibliothèqueImage }) as Graphique;
                    grphs.Add(grph);
                    /*}
                    catch() {  }*/
                }
                return grphs;
            }

            foreach(XmlNode nd in xmln.ChildNodes)
            {
                for (idx = 0; idx < svgKeywrd.Length && !svgKeywrd[idx].Equals(nd.Name); ++idx);
                if(idx < svgKeywrd.Length)
                {
                    Type gTypT = Graphique.GTypeT[idx];
                    //public svg(string path, XmlNode paq, BibliothèqueImage bibliothèqueImage)
                    ConstructorInfo cstr = gTypT.GetConstructor(new Type[] { typeof(string), typeof(XmlNode), typeof(BibliothèqueImage) });
                    if (cstr != null)
                    {
                        /*try
                        {*/
                            Graphique grph = cstr.Invoke(new object[] { chmImg, nd, bibliothèqueImage }) as Graphique;
                            grphs.Add(grph);
                        /*}
                        catch() {  }*/
                    }
                }
            }
            if (!grphs.Any()) grphs = null;
            return grphs;
        }

        static public List<Graphique> ChargerSVG(string chmImg, string nomImg, BibliothèqueImage bibliothèqueImage)
        {
            XmlDocument doc = new XmlDocument();
            try { doc.Load(chmImg + nomImg); } catch { return null; }
            return ChargerSVG(chmImg, doc.ChildNodes.Item(0), bibliothèqueImage);
        }

        static public (PointF, PointF) CalculerMinMax(List<Graphique> grphs)
        {
            if (grphs.Any())
            {
                PointF pmin = new PointF(float.MaxValue, float.MaxValue);
                PointF pmax = new PointF(float.MinValue, float.MinValue);
                foreach (Graphique grph in grphs)
                {
                    var pmmx = grph.MinMax;
                    pmin.X = Math.Min(pmin.X, pmmx.Item1.X);
                    pmin.Y = Math.Min(pmin.Y, pmmx.Item1.Y);
                    pmax.X = Math.Max(pmax.X, pmmx.Item2.X);
                    pmax.Y = Math.Max(pmax.Y, pmmx.Item2.Y);
                }
                return (pmin, pmax);
            }
            else return (new PointF(), new PointF());
        }

        static public SizeF CentrerEtDimensionner(List<Graphique> grphs)
        {
            if (grphs != null)
            {
                var pmmx = Graphique.CalculerMinMax(grphs);
                PointF ctrp = new PointF((pmmx.Item1.X + pmmx.Item2.X) / 2.0f, (pmmx.Item1.Y + pmmx.Item2.Y) / 2.0f);
                grphs.ForEach(g => g.Centrer(ctrp));
                return new SizeF(pmmx.Item2.X - pmmx.Item1.X, pmmx.Item2.Y - pmmx.Item1.Y);
            }
            else return new SizeF(0.0f, 0.0f);
        }

        static public SizeF CentrerEtDimensionner(List<Graphique> grphs, (PointF, PointF) pmmx)
        {
            if (grphs != null)
            {
                PointF ctrp = new PointF((pmmx.Item1.X + pmmx.Item2.X) / 2.0f, (pmmx.Item1.Y + pmmx.Item2.Y) / 2.0f);
                grphs.ForEach(g => g.Centrer(ctrp));
                return new SizeF(pmmx.Item2.X - pmmx.Item1.X, pmmx.Item2.Y - pmmx.Item1.Y);
            }
            else return new SizeF(0.0f, 0.0f);
        }

        /*static public Rectangle Rect(Image img) { return new Rectangle(0, 0, img.Width, img.Height); }
        static public RectangleF RectF(Image img) { return new RectangleF(0, 0, img.Width, img.Height); }*/

        virtual public GType GraphType { get => GType.Vide; }
        virtual public object GraphiqueDessus { get => null; }
        virtual public object GraphiqueDessous { get => null; }

        abstract public void Centrer(PointF ctr);

        /*public Graphique(Stream stream, IRessourcesDésérialiseur resscDes)
        {
            IdentifiantRéseau = BitConverter.ToInt32(stream.GetBytes(4), 0);
            resscDes.NouvelleElement(this);
            GC = stream.ReadGeoCoord2D();
            Ordre = (sbyte)stream.ReadByte();
            etat = (EEtat)stream.ReadByte();
            Parent = resscDes.Rechercher(BitConverter.ToInt32(stream.GetBytes(4), 0)) as Element;
        }*/

        virtual public void Serialiser(Stream stream, Graphique vide = null)
        {
            stream.WriteByte((byte)GraphType);
            /*stream.WriteByte((byte)ElmType);
            if (IdRéseauVacantModifiable(gidr)) ElmId = gidr.IdRéseauSuivant();
            stream.Serialiser(BitConverter.GetBytes(IdentifiantRéseau));
            stream.SerialiserObject(GC);
            stream.WriteByte((byte)Ordre);
            stream.WriteByte((byte)etat);
            stream.SerialiserRefElement(Parent, ref gidr);*/
        }

        static public void Serialiser(Graphique graphique, Stream stream, Graphique vide = null)
        {
            if (graphique != null && graphique != vide) graphique.Serialiser(stream, vide);
            else stream.WriteByte(0);
        }

        virtual public (PointF, PointF) MinMax { get { var s = SizeF; s.Width /= 2.0f; s.Height /= 2.0f; return (new PointF(-s.Width, -s.Height), new PointF(s.Width, s.Height)); } }

        public Rectangle Rect { get { var s = Size; return new Rectangle(0, 0, s.Width, s.Height); } }
        public RectangleF RectF { get { var s = SizeF; return new RectangleF(0, 0, s.Width, s.Height); } }

        public float SclRatio { get
            {
                SizeF sz = SizeF;
                float m = Math.Min(sz.Width, sz.Height);
                return ((m > 0.0001) ? 1.0f / m : 1.0f);
            }
        }

        public float ObtenirSclRatio(float E)
        {
            SizeF sz = SizeF;
            float m = Math.Min(sz.Width, sz.Height);
            return ((m > 0.0001) ? E / m : E);
        }

        /*public Matrix ScaleTransform(Graphics g, float E)
        {
            Matrix rt = g.Transform;
            SizeF sz = SizeF;
            float m = Math.Min(sz.Width, sz.Height);
            float scl = ((m > 0.0001) ? E / m : E);
            g.ScaleTransform(scl, scl);
            return rt;
        }*/

        abstract public Size Size { get; }
        abstract public SizeF SizeF { get; }

        public Point PSize { get { Size sz = Size; return new Point(sz.Width, sz.Height); } }
        public PointF PSizeF { get { SizeF sz = SizeF; return new PointF(sz.Width, sz.Height); } }

        /*public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, RectangleF dRect, bool Retournée)
        {
            Matrix res;

            if (Dessus != null)
            {
                float sclRatio = GC.E / Math.Min(Dessus.Width, Dessus.Height);
                Matrix m = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                if (Retournée) g.ScaleTransform(-sclRatio, sclRatio);
                else g.ScaleTransform(sclRatio, sclRatio);
                //g.DrawImage(img, dRect, new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
                g.DrawImage(Dessus, dRect);
                res = g.Transform;
                g.Transform = m;
                //g.FillRectangle(new SolidBrush(Color.Black), drect);
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);

            return res;
        }*/
        public Matrix Dessiner(RectangleF vue, Graphics g, GeoCoord2D GC, bool Retournée)
        {
            Matrix res;
            SizeF sz = SizeF;
            float mSz = Math.Min(sz.Width, sz.Height);

            Matrix m = g.Transform;
            g.TranslateTransform(GC.P.X, GC.P.Y);
            g.RotateTransform(GC.A);
            if(mSz > 0.0001)
            {
                float sclRatio = ((mSz > 0.0001) ? GC.E / mSz : GC.E);
                g.ScaleTransform(sclRatio, sclRatio);
            }
            Dessiner(g, Retournée);
            res = g.Transform;
            g.Transform = m;

            return res;
        }

        abstract public void Dessiner(Graphics g, bool Retournée);

        public Matrix DessinerVide(RectangleF vue, Graphics g, GeoCoord2D GC)
        {
            Matrix res;
            SizeF sz = SizeF;
            if (sz.Width > 0 && sz.Height > 0)
            {
                float sclRatio = Math.Min(sz.Width, sz.Height);
                RectangleF dRect = new RectangleF(-sz.Width / 2, -sz.Height / 2, sz.Width, sz.Height);

                Matrix m = g.Transform;
                sclRatio = GC.E / sclRatio;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                g.RotateTransform(GC.A);
                g.ScaleTransform(sclRatio, sclRatio);
                g.FillRectangle(new SolidBrush(Color.Gray), dRect);
                res = g.Transform;
                g.Transform = m;
            }
            else res = Graphique.DessinerVide(new Point(20, 20), vue, g, GC);
            return res;
        }

        abstract public void MettreAJour(object obj);

        public Graphique CloneGraph()
        {
            return Clone() as Graphique;
        }

        public object Clone()
        {
            return this;
        }
    }
}
