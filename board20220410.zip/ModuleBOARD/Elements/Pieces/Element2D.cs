﻿using ModuleBOARD.Elements.Base;
using ModuleBOARD.Elements.Base.Graphiques;
using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ModuleBOARD.Elements.Pieces
{
    public class Element2D : Element
    {
        //public SImage SImg = default;
        public Graphique ElmGraph = default;
        public override EType ElmType { get => EType.Element2D; }

        public override PointF Size { get => GC.ProjSize(ElmGraph.Rect); }

        public Element2D()
        {
        }
        public Element2D(Graphique grph)
        {
            ElmGraph = grph;
        }

        public Element2D(Element2D elm)
            :base(elm)
        {
            ElmGraph = elm.ElmGraph;
        }

        public Element2D(string path, string dessus, PointF p, BibliothèqueImage bibliothèqueImage)
        {
            GC.P = p;
            ElmGraph = new ImageSimple(bibliothèqueImage.ChargerImage(path, dessus));
        }

        public Element2D(string path, string dessus, string dessous, PointF p, BibliothèqueImage bibliothèqueImage)
        {
            GC.P = p;
            ElmGraph = new ImageDouble(bibliothèqueImage.ChargerImage(path, dessus), bibliothèqueImage.ChargerImage(path, dessous));
        }

        /*private void TEST()
        {
            while(true)
            {
                MemoryStream stream = new MemoryStream();
                ElmImage.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
        }*/

        public Element2D(string path, XmlNode paq, PointF p, BibliothèqueImage bibliothèqueImage)
        {
            Load(paq);
            GC.P.X += p.X;
            GC.P.Y += p.Y;
            string fileDessus = paq.Attributes.GetNamedItem("img")?.Value;
            Image imgDessus = fileDessus != null ? bibliothèqueImage.ChargerSImage(path, fileDessus, paq, "ix", "iy", "w", "h") : null;
            string fileDessous = paq.Attributes.GetNamedItem("dos")?.Value;
            Image imgDessous = fileDessous != null ? bibliothèqueImage.ChargerSImage(path, fileDessous, paq, "dx", "dy", "w", "h") : null;

            if (imgDessus != null)
            {
                if (imgDessous != null) ElmGraph = new ImageDouble(imgDessus, imgDessous);
                else ElmGraph = new ImageSimple(imgDessus);
            }
            else if (imgDessous != null) ElmGraph = new ImageSimple(imgDessous);
            else ElmGraph = default;
        }

        public override void Dessiner(ushort idJoueur, RectangleF vue, float angle, Graphics g, bool retourné = false)
        {
            /*p.X += GC.P.X;
            p.Y += GC.P.Y;*/
            //Matrix m = g.Transform;
            ElmGraph.Dessiner(vue, g, GC, EstDansEtat(EEtat.Retournée) ^ retourné);
            //g.Transform = m;
        }

        public bool IsValid() { return ElmGraph != null; }

        override public object MettreAJour(object obj)
        {
            if (ElmGraph != null) ElmGraph.MettreAJour(obj);
            return base.MettreAJour(obj);
        }

        public override bool PutOnTop(Element elm)
        {
            return (this == elm);
        }

        public override bool Lier(XmlNode paq, Dictionary<string, Element> dElements)
        {
            return true;
        }

        public override bool Equals(object obj)
        {
            if (Object.ReferenceEquals(this, obj)) return true;
            else if (obj is Element2D)
            {
                Element2D elm = obj as Element2D;
                return GC.E == elm.GC.E && BibliothèqueImage.Equals(ElmGraph, elm.ElmGraph);
            }
            else return false;
        }

        public override object Clone()
        {
            return new Element2D(this);
        }

        override public ContextMenu Menu(IBoard ctrl, Joueur jr, Element elmRt)
        {
            ContextMenu cm = base.Menu(ctrl, jr, elmRt);
            if (cm == null) cm = new ContextMenu();

            cm.MenuItems.AddRange(new MenuItem[]
                    {
                        new MenuItem("Créer la pioche", new EventHandler((o,e) => {ctrl.MettreEnPioche(jr, elmRt, this); })),
                    });
            return cm;
        }

        public Element2D(Stream stream, IRessourcesDésérialiseur resscDes)
            : base(stream, resscDes)
        {
            ElmGraph = resscDes.RécupérerGraphique(stream);
        }

        override public void Serialiser(Stream stream, ref int gidr)
        {
            base.Serialiser(stream, ref gidr);
            Graphique.Serialiser(ElmGraph, stream);
        }

        override public void SerialiserTout(Stream stream, ref int gidr, ISet<int> setIdRéseau)
        {
            base.SerialiserTout(stream, ref gidr, setIdRéseau);
        }
    }
}
