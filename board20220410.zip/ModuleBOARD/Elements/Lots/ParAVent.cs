﻿using ModuleBOARD.Elements.Base;
using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ModuleBOARD.Elements.Lots
{
    public class ParAVent : Groupe
    {
        [Flags]
        public enum EConfig : ushort
        {
            Néant = 0,

            Visible = (1 << 0), // Le contenu du paravent est visible pour les autres joueurs
            EstUneMain = (1 << 1), // Le joueur voit ses pièces de la face opposée (Si le joueur voient ses cartes face visible, alors, les autres joueurs voient le dos et inversement)
            //EstInversé = (1 << 2), Existe déjà dans l'état // Inverse le rendu Une pièce attrapée est retournée. // ça permet par exemple de ne jamais voir la carte comme dans Hanabis
            AttraperRetourne = (1 << 2), // ça permet de jouer direct face visible 

            AuthoriserADéplacer = (1 << 3), // Permet à un autre joueur d'attraper le paravent
            AuthoriserAPiocher = (1 << 4), // Permet à un autre joueur d'attraper une pièce
            AuthoriserAPiocherAuHazard = (1 << 5), // Permet à un autre joueur d'attraper une pièce au hazard
            AuthoriserADéposer = (1 << 6), // Permet à un autre joueur de déposer une pièce
            AuthoriserATourner = (1 << 7), // Permet à un autre joueur de tourner une pièce
            AuthoriserARetourner = (1 << 8), // Permet à un autre joueur de retourner une pièce
        }

        static public readonly int Marge = 40;
        static public readonly int TailleMinimale = 200 + 2 * Marge;

        public ushort IdJoueur; // Identifiant dans la session du joueur auquel appartient ce paravent
        public string Titre; // Nom du joueur auquel le paravent appartient
        public Color CouleurJoueur;
        private EConfig configuration;
        private PointF size;
        public List<ushort> PartageJoueur;

        public GeoVue ObtenirPointDeVue(PointF ecran)
        {
            float scl = Math.Min(ecran.X / size.X, ecran.Y / size.Y);
            if (scl < 0.13f) scl = 0.13f;
            else if (scl > 6.19f) scl = 6.19f;
            return new GeoVue(GC.P.X , GC.P.Y, scl, GeoCoord2D.AngleModulo(-GC.A), ecran.X, ecran.Y);
        }

        public override int ElmId { get => IdentifiantRéseau; set => IdentifiantRéseau = value; }
        public override EType ElmType { get => EType.ParAVent; }

        public override PointF Size { get => size; }

        public bool ADroits(EConfig droit) { return configuration.HasFlag(droit); }
        public void MajConfiguration(EConfig Configuration)
        {
            //Est-ce que le fait que ce soit une main ou non a changé ?
            if ((configuration ^ Configuration).HasFlag(EConfig.EstUneMain))
            {
                if (configuration.HasFlag(EConfig.EstUneMain)) // était une main ?
                    Titre = "Paravent" + Titre.Substring("Main".Length);
                else Titre = "Main" + Titre.Substring("Paravent".Length); ;
            }
            configuration = Configuration;
        }

        public override bool IsAt(PointF mp, float angle)
        {
            return IsAt(mp, size, angle);
        }

        public override bool IsAt(PointF mp, PointF psz, float angle)
        {
            psz.X /= 2.0f;
            psz.Y /= 2.0f;

            mp.X -= GC.P.X/* - (psz.X / 2.0f)*/;
            mp.Y -= GC.P.Y/* - (psz.Y / 2.0f)*/;

            Matrix m = new Matrix();
            m.Rotate(GC.A);
            PointF nmp = new PointF
                (
                    mp.X * m.Elements[0] + mp.Y * m.Elements[1],
                    mp.X * m.Elements[2] + mp.Y * m.Elements[3]
                );

            return (-psz.X <= nmp.X && -psz.Y <= nmp.Y && nmp.X <= psz.X && nmp.Y <= psz.Y);
        }

        public ParAVent()
        {
            base.MajEtat(EEtat.RotationFixe);
            size = new PointF(TailleMinimale, TailleMinimale);
            configuration = EConfig.Visible;
        }

        public void MAJPropriétaire(Joueur jr)
        {
            if (jr != null)
            {
                if (configuration.HasFlag(EConfig.EstUneMain)) Titre = "Main";
                else Titre = "Paravent";
                IdJoueur = jr.IdSessionJoueur;
                if (!String.IsNullOrWhiteSpace(jr.Nom)) Titre += " de " + jr.Nom;
                CouleurJoueur = jr.Couleur;
            }
            else if(IdJoueur != 0)
            {
                IdJoueur = 0;
                //CouleurJoueur = Color.Black;
                //if (configuration.HasFlag(EConfig.EstUneMain)) Titre = "Main";
                //else Titre = "Paravent";
            }
        }

        public ParAVent(Joueur jr, EConfig _droits)
        {
            base.MajEtat(EEtat.RotationFixe);
            configuration = _droits;
            MAJPropriétaire(jr);
            size = new PointF(TailleMinimale, TailleMinimale);
        }

        public ParAVent(ParAVent elm)
            :base(elm)
        {
            base.MajEtat(EEtat.RotationFixe);
            configuration = elm.configuration;
            size = elm.size;
        }




        private void Recadrer(Element elm)
        {
            PointF pmin, pmax;
            (pmin, pmax) = PointFMinMax;

            PointF pmoy = new PointF((pmin.X + pmax.X) / 2.0f, (pmin.Y + pmax.Y) / 2.0f);
            Décaler(new PointF(-pmoy.X, -pmoy.Y));

            Matrix m = new Matrix();
            m.Rotate(-GC.A);
            PointF rpmoy = new PointF
                (
                    pmoy.X * m.Elements[0] + pmoy.Y * m.Elements[1],
                    pmoy.X * m.Elements[2] + pmoy.Y * m.Elements[3]
                );

            GC.P.X += rpmoy.X;
            GC.P.Y += rpmoy.Y;

            size = new PointF(Math.Max(TailleMinimale, 2 * Marge + pmax.X - pmin.X), Math.Max(TailleMinimale, 2 * Marge + pmax.Y - pmin.Y));
        }

        private bool EstLocalElementLimite(Element elm)
        {
            PointF sz = elm.Size;
            float fmax = 10.0f + Marge + Math.Max(sz.X, sz.Y) / 2.0f;
            //size
            PointF sz2 = new PointF(size.X / 2.0f, size.Y / 2.0f);
            return ((elm.GC.P.X - fmax) <= -sz2.X || sz2.X <= (elm.GC.P.X + fmax) ||
                    (elm.GC.P.Y - fmax) <= -sz2.Y || sz2.Y <= (elm.GC.P.Y + fmax)   );
        }

        public override Element ElementLaché(Element elm)
        {
            Element res = base.ElementLaché(elm);
            if (res == null)
            {
                if(EstLocalElementLimite(elm)) Recadrer(elm);
                return null;
            }
            else return res;
        }

        public void DessinerPropriétaire(ushort idJoueur, RectangleF vue, float angle, Graphics g, bool retourné = false)
        {
            retourné ^= configuration.HasFlag(EConfig.EstUneMain);

            Matrix svMat = g.Transform;
            g.TranslateTransform(GC.P.X, GC.P.Y);
            if (GC.A != 0.0f)
            {
                g.RotateTransform(GC.A);
                //angle += GC.A;
            }
            //Pen pn = new Pen(CouleurJoueur, 5);
            Brush brshBk = new SolidBrush(Color.FromArgb(64, CouleurJoueur));
            Brush brsh = new SolidBrush(Color.FromArgb(CouleurJoueur.R / 2, CouleurJoueur.G / 2, CouleurJoueur.B / 2));
            float sz2X = (size.X / 2.0f);
            float sz2Y = (size.Y / 2.0f);
            g.FillRectangle(brshBk, -sz2X, -sz2Y, size.X, size.Y);
            g.DrawString(Titre, new Font(FontFamily.GenericMonospace, 20.0f, FontStyle.Bold), brsh, -sz2X, -sz2Y);
            g.Transform = svMat;

            base.Dessiner(idJoueur, vue, angle, g, retourné);
        }

        public override void Dessiner(ushort idJoueur, RectangleF vue, float angle, Graphics g, bool retourné = false)
        {
            if (PartageJoueur != null && PartageJoueur.Contains(idJoueur))
                DessinerPropriétaire(idJoueur, vue, angle, g, retourné);
            else
            {
                Matrix svMat = g.Transform;
                g.TranslateTransform(GC.P.X, GC.P.Y);
                if (GC.A != 0.0f)
                {
                    g.RotateTransform(GC.A);
                    //angle += GC.A;
                }
                //Pen pn = new Pen(CouleurJoueur, 5);
                Brush brshBk = new SolidBrush(Color.FromArgb(64, CouleurJoueur));
                Brush brsh = new SolidBrush(Color.FromArgb(CouleurJoueur.R / 2, CouleurJoueur.G / 2, CouleurJoueur.B / 2));
                float sz2X = (size.X / 2.0f);
                float sz2Y = (size.Y / 2.0f);
                g.FillRectangle(brshBk, -sz2X, -sz2Y, size.X, size.Y);
                g.DrawString(Titre, new Font(FontFamily.GenericMonospace, 20.0f, FontStyle.Bold), brsh, -sz2X, -sz2Y);
                g.Transform = svMat;
                if (configuration.HasFlag(EConfig.Visible)) base.Dessiner(idJoueur, vue, angle, g, retourné);
            }
        }

        public void PartagerAjouter(ushort jr)
        {
            if (PartageJoueur == null) PartageJoueur = new List<ushort>() { jr };
            else if (!PartageJoueur.Contains(jr)) PartageJoueur.Add(jr);
        }

        public void PartagerRetirer(ushort jr)
        {
            if (PartageJoueur != null)
            {
                PartageJoueur.Remove(jr);
                if (PartageJoueur.Count == 0) PartageJoueur = null;
            }
        }

        public void PurgerAbsent(HashSet<ushort> lstJrIds)
        {
            if(lstJrIds != null && PartageJoueur != null)
            {
                PartageJoueur.RemoveAll(i => !lstJrIds.Contains(i));
                if (PartageJoueur.Count == 0) PartageJoueur = null;
            }
        }

        /*public override (Element, Element) MousePickAvecContAt(PointF mp, float angle, EPickUpAction action = 0)
        {
        }

        public override List<(Element, Element)> MousePickAllAvecContAt(PointF mp, float angle, EPickUpAction action = 0)
        {
        }

        public override Element MousePickAt(PointF mp, float angle, EPickUpAction action = 0)
        {
        }

        public override List<Element> MousePickAllAt(PointF mp, float angle, EPickUpAction action = 0)
        {
        }*/

        public override bool Roulette(int delta) { Tourner(delta); return true; }

        public override void Tourner(int delta)
        {
            if (!EstDansEtat(EEtat.RotationFixe))
            {
                int oldA = (int)(GC.A + 0.5f);
                int newA = oldA + delta;
                GC.A = GeoCoord2D.AngleFromToAimant45(oldA, newA); // delta * 45.0f;
            }
        }

        public override Element RangerVersParent(Element parent)
        {
            Element res = base.RangerVersParent(parent);
            if (res != null) Recadrer(null);
            return res;
        }

        public override Element DéfausserElement(Element relem)
        {
            Element res = base.DéfausserElement(relem);
            if (res != null) Recadrer(null);
            return res;
        }

        public override Element DétacherElement(Element relem)
        {
            bool estLocLim = EstLocalElementLimite(relem);
            Element res = base.DétacherElement(relem);
            if(res != null && estLocLim) Recadrer(null);
            return res;
        }

        override public object MettreAJour(object obj)
        {
            object res = base.MettreAJour(obj);
            if (res != null) Recadrer(res as Element);
            return res;
        }

        public override Element Suppression(Element elm)
        {
            bool estLocLim = EstLocalElementLimite(elm);
            Element res = base.Suppression(elm);
            if (res != null && estLocLim) Recadrer(null);
            return res;
        }

        public override List<Element> MouseCatchAt(PointF mp, float angle, ushort idJr , EPickUpAction action)
        {
            if (ADroit(idJr, action)) return base.MouseCatchAt(mp, angle, idJr, action);
            else return null;
        }

        public override List<Element> MouseCatchAt(HashSet<int> netIds, ushort idJr , EPickUpAction action)
        {
            if (ADroit(idJr, action)) return base.MouseCatchAt(netIds, idJr, action);
            else return null;
        }

        private bool ADroit(ushort idJrAct, EPickUpAction action)
        {
            return  IdJoueur == 0 ||
                    action.HasFlag(EPickUpAction.Propriétaire) ||
                    (PartageJoueur != null && PartageJoueur.Contains(idJrAct)) ||
                (
                    configuration.HasFlag(EConfig.Visible) &&
                    (!action.HasFlag(EPickUpAction.OuvrirMenu)) &&
                    (!action.HasFlag(EPickUpAction.Tourner) || configuration.HasFlag(EConfig.AuthoriserATourner)) &&
                    (!(action.HasFlag(EPickUpAction.Retourner) || action.HasFlag(EPickUpAction.Roulette)) || configuration.HasFlag(EConfig.AuthoriserARetourner)) &&
                    (!(action.HasFlag(EPickUpAction.Attraper) || action.HasFlag(EPickUpAction.Piocher)) || (configuration.HasFlag(EConfig.AuthoriserAPiocher) || configuration.HasFlag(EConfig.AuthoriserAPiocherAuHazard))) &&
                    (!action.HasFlag(EPickUpAction.Déposer) || configuration.HasFlag(EConfig.AuthoriserADéposer))
                );
        }

        //(Element, Conteneur)
        public override (Element, Element) MousePickAvecContAt(PointF mp, float angle, ushort idJr, EPickUpAction action = 0)
        {
            if (ADroit(idJr, action)) return base.MousePickAvecContAt(mp, angle, idJr, action);
            else return (null, null);
        }

        public override Element MousePickAt(PointF mp, float angle, ushort idJr , EPickUpAction action = EPickUpAction.Néant)
        {
            if (ADroit(idJr, action)) return base.MousePickAt(mp, angle, idJr, action);
            else return null;
        }

        public override (List<Element>, Element) MouseCatchAvecContAt(PointF mp, float angle, ushort idJr , EPickUpAction action)
        {
            if (ADroit(idJr, action)) return base.MouseCatchAvecContAt(mp, angle, idJr, action);
            else return (null, null);
        }

        public override (List<Element>, Element) MouseCatchAllInAvecContAt(PointF mpDb, PointF mpFn, Matrix m, ushort idJr , EPickUpAction action)
        {
            if (ADroit(idJr, action)) return base.MouseCatchAllInAvecContAt(mpDb, mpFn, m, idJr, action);
            else return (null, null);
        }

        public override Element MousePickAt(int netId, ushort idJr, Element.EPickUpAction action)
        {
            if (ADroit(idJr, action)) return base.MousePickAt(netId, idJr, action);
            else return null;
        }

        new public void Nétoyer()
        {
            base.Nétoyer();
            size = new PointF(TailleMinimale, TailleMinimale);
        }

        /*
            Visible = (1 << 0), // Le contenu du paravent est visible pour les autres joueurs
            EstUneMain = (1 << 1), // Le joueur voit ses pièces de la face opposée (Si le joueur voient ses cartes face visible, alors, les autres joueurs voient le dos et inversement)
            AttraperRetourne = (1 << 2), // Une pièce attrapée est retournée. // ça permet de jouer direct face visible

            AuthoriserADéplacer = (1 << 4), // Permet à un autre joueur d'attraper le paravent
            AuthoriserAPiocher = (1 << 5), // Permet à un autre joueur d'attraper une pièce
            AuthoriserAPiocherAuHazard = (1 << 6), // Permet à un autre joueur d'attraper une pièce au hazard
            AuthoriserADéposer = (1 << 7), // Permet à un autre joueur de déposer une pièce
            AuthoriserATourner = (1 << 8), // Permet à un autre joueur de tourner une pièce
            AuthoriserARetourner = (1 << 9), // Permet à un autre joueur de retourner une pièce
         */

        static private readonly string[][] libellé_paravent_config = new string[][]
            {
                new string[2]{ "Montrer le paravent", "Cacher le paravent" },
                new string[2]{ "Convertir en main", "Convertir en paravent" },
                new string[2]{ "Retourner sortant", "Ne pas retourner sortant" },
                new string[2]{ "Authoriser à prendre le paravent", "Interdir de prendre le paravent" },
                new string[2]{ "Authoriser à piocher un élément", "Interdir de piocher un élément" },
                new string[2]{ "Authoriser à piocher au hazard", "Interdir de piocher au hazard" },
                new string[2]{ "Authoriser à déposer un élément", "Interdir de déposer un élément" },
                new string[2]{ "Authoriser à tourner un élément", "Interdir de tourner un élément" },
                new string[2]{ "Authoriser à retourner un élément", "Interdir de retourner un élément" }
            };

        static private readonly string[][] libellé_main_config = new string[][]
            {
                new string[2]{ "Montrer la main", "Cacher la main" },
                new string[2]{ "Convertir en main", "Convertir en paravent" },
                new string[2]{ "Retourner sortant", "Ne pas retourner sortant" },
                new string[2]{ "Authoriser à prendre la main", "Interdir de prendre la main" },
                new string[2]{ "Authoriser à piocher un élément", "Interdir de piocher un élément" },
                new string[2]{ "Authoriser à piocher au hazard", "Interdir de piocher au hazard" },
                new string[2]{ "Authoriser à déposer un élément", "Interdir de déposer un élément" },
                new string[2]{ "Authoriser à tourner un élément", "Interdir de tourner un élément" },
                new string[2]{ "Authoriser à retourner un élément", "Interdir de retourner un élément" }
            };

        override public ContextMenu Menu(IBoard ctrl, Joueur jr, Element elmRt)
        {
            ContextMenu cm = base.Menu(ctrl, jr, elmRt);
            if (cm == null) cm = new ContextMenu();

            string[][] libellé_config = (configuration.HasFlag(EConfig.EstUneMain) ? libellé_main_config : libellé_paravent_config);
            MenuItem[] mConfig = new MenuItem[libellé_config.Length];
            for (int i = 0; i < libellé_config.Length; ++i)
            {
                EConfig cfg = (EConfig)(1 << i);
                if (configuration.HasFlag((EConfig)(1 << i))) mConfig[i] = new MenuItem(libellé_config[i][1], new EventHandler((o, e) => { ctrl.MAJConfigParAVent(this, configuration ^ cfg); }));
                else mConfig[i] = new MenuItem(libellé_config[i][0], new EventHandler((o, e) => { ctrl.MAJConfigParAVent(this, configuration ^ cfg); }));
            }
            cm.MenuItems.Add("Configuration", mConfig);

            List<Joueur> lstJrs = ctrl.ObtenirListeJoueurs();
            if (lstJrs != null && lstJrs.Count > 0)
            {
                MenuItem[] mPartage = new MenuItem[lstJrs.Count];
                for (int i = 0; i < mPartage.Length; ++i)
                {
                    ushort idJr = lstJrs[i].IdSessionJoueur;
                    if (PartageJoueur != null && PartageJoueur.Contains(lstJrs[i].IdSessionJoueur))
                         mPartage[i] = new MenuItem(lstJrs[i].Nom + "(-)", new EventHandler((o, e) => { ctrl.PartageParAVentRetirerJoueur(jr, elmRt, this, idJr); }));
                    else mPartage[i] = new MenuItem(lstJrs[i].Nom + "(+)", new EventHandler((o, e) => { ctrl.PartageParAVentAjouterJoueur(jr, elmRt, this, idJr); }));
                }
                cm.MenuItems.Add("Partager", mPartage);
            }

            if (jr == null) cm.MenuItems.Add(new MenuItem("Revendiquer ce paravent", new EventHandler((o, e) => { ctrl.RevendiquerParAVent(this); })));
            else cm.MenuItems.Add(new MenuItem("Révoquer ce paravent", new EventHandler((o, e) => { ctrl.RévoquerParAVent(this); })));

            return cm;
        }













        override public object Clone()
        {
            return new ParAVent(this);
        }

        public override bool Equals(object obj)
        {
            if (Object.ReferenceEquals(this, obj)) return true;
            else if (obj is ParAVent)
            {
                ParAVent prv = obj as ParAVent;
                if (prv.size.X == size.X && prv.size.Y == size.Y) return base.Equals(obj);
                else return false;
            }
            else return false;
        }





        public ParAVent(Stream stream, IRessourcesDésérialiseur resscDes)
            : base(stream, resscDes)
        {
            configuration = (EConfig)stream.DésérialiserObject(typeof(EConfig));
            Titre = stream.ReadString();
            IdJoueur = stream.ReadUShort();
            CouleurJoueur = Color.FromArgb(stream.ReadInt());
            size = stream.ReadPointF();
        }

        override public void Serialiser(Stream stream, ref int gidr)
        {
            base.Serialiser(stream, ref gidr);
            stream.SerialiserObject(configuration);
            stream.SerialiserObject(Titre ?? "");
            stream.WriteBytes(BitConverter.GetBytes((ushort)(IdJoueur)));
            stream.WriteBytes(BitConverter.GetBytes((Int32)(CouleurJoueur.ToArgb())));
            stream.SerialiserObject(size, typeof(PointF));
        }

        /*override public void SerialiserTout(Stream stream, ref int gidr, ISet<int> setIdRéseau)
        {
            base.SerialiserTout(stream, ref gidr, setIdRéseau);
        }*/
    }
}
