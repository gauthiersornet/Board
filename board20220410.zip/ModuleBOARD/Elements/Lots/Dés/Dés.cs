﻿using ModuleBOARD.Elements.Base;
using ModuleBOARD.Elements.Pieces;
using ModuleBOARD.Réseau;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace ModuleBOARD.Elements.Lots.Dés
{
    public class Dés : Element
    {
        static private float CroixEpaisseur = 5.0f;

        public override EType ElmType { get => EType.Dés; }
        public List<Graphique> Images = null;
        public int Courrante = -1;

        protected Dés() { }

        protected Dés(int idREz) : base(idREz) { }

        public Dés(Element elm) : base(elm) { }

        public Dés(Element2D element2D) : base(element2D)
        {
            Parent = null;
            Images = new List<Graphique>() { element2D.ElmGraph };
        }

        public Dés(Dés elm)
            : base(elm)
        {
            Images = (elm.Images != null ? new List<Graphique>(elm.Images) : null);
            Courrante = elm.Courrante;
        }

        public Dés(string path, XmlNode paq, PointF p, BibliothèqueImage bibliothèqueImage)
        {
            base.Load(paq);
            GC.P.X += p.X;
            GC.P.Y += p.Y;
            //Parent = parent;
            if (paq.Attributes?.GetNamedItem("echl") == null) GC.E = 40.0f;

            Images = bibliothèqueImage.ChargerFacesImage(path, paq.ChildNodes);
            /*if(Images != null)
            {
                GC.P.X -= Images.Count * CEpaisseur;
                GC.P.Y -= Images.Count * CEpaisseur;
            }*/

            /*string fileImg = paq.Attributes?.GetNamedItem("carte")?.Value;
            if (fileImg != null)
            {
                List<SImage> lstSImgs = SImage.LoadSImages(path, fileImg, paq);
                if(lstSImgs!=null && lstSImgs.Count > 0) Images.AddRange(lstSImgs);
            }*/

            if (paq.Attributes?.GetNamedItem("mélanger") != null) Mélanger();

            if (paq.Attributes?.GetNamedItem("caché") != null)
                Courrante = -1;
            else if (paq.Attributes?.GetNamedItem("montré") != null)
                Courrante = 0;
            else Courrante = -1;
        }

        public override PointF Size
        {
            get
            {
                Graphique imgref;
                if (Images != null && Images.Any()) imgref = Images.FirstOrDefault(x => x != null);
                else imgref = null;

                PointF sz;
                if (imgref != null) sz = GC.ProjSize(imgref.Rect);
                else sz = GC.ProjSize(new Rectangle(0, 0, 20, 20));
                return sz;
            }
        }

        public override object Clone(){ return new Dés(this); }

        public override void Dessiner(ushort idJoueur, RectangleF vue, float angle, Graphics g, bool retourné = false)
        {
            GeoCoord2D gc = GC;

            Matrix m = g.Transform;
            if (Images != null && Images.Any())
            {
                int idx;
                if (Courrante >= 0)
                {
                    if (Courrante >= Images.Count) Courrante = 0;
                    if (retourné) idx = Images.Count + ~Courrante;
                    else idx = Courrante;
                }
                else
                {
                    if (Courrante < -Images.Count) Courrante = -1;
                    if (retourné) idx = ~Courrante;
                    else idx = Images.Count + Courrante;
                }
                if(Images[idx] != null) Images[idx].Dessiner(vue, g, gc, (Courrante < 0) ^ retourné);
                else Graphique.DessinerVide(new Point(20, 20), vue, g, gc);
            }
            else
            {
                Matrix drawMat = Graphique.DessinerVide(new Point(20, 20), vue, g, gc);
                g.Transform = drawMat;
                RectangleF rect = new RectangleF(0, 0, 20, 20);
                Pen pn = new Pen(Color.Black, CroixEpaisseur);
                /*g.DrawLine(pn, new PointF(rect.X, rect.Y), new PointF(rect.X + rect.Width, rect.Y + rect.Height));
                g.DrawLine(pn, new PointF(rect.X + rect.Width, rect.Y), new PointF(rect.X, rect.Y + rect.Height));*/
                g.DrawLine(pn, new PointF(-rect.Width / 2, -rect.Height / 2), new PointF(rect.Width / 2, rect.Height / 2));
                g.DrawLine(pn, new PointF(rect.Width / 2, -rect.Height / 2), new PointF(-rect.Width / 2, rect.Height / 2));
            }
            g.Transform = m;
        }

        override public object MettreAJour(object obj)
        {
            if (obj is Graphique)
            {
                if (Images != null) Images.ForEach(i => i.MettreAJour(obj));
                return base.MettreAJour(obj);
            }
            else return base.MettreAJour(obj);
        }

        protected void MettreAJourEtat()
        {
            if (EstDansEtat(EEtat.Retournée))
            {
                if (Courrante >= 0) Courrante = ~Courrante;
            }
            else
            {
                if (Courrante < 0) Courrante = ~Courrante;
            }
        }

        public override void MajEtat(EEtat nouvEtat)
        {
            if (AEtatChangé(EEtat.Retournée, nouvEtat))
            {
                Courrante = ~Courrante;
            }
            base.MajEtat(nouvEtat);
        }

        public override bool Roulette(int delta)
        {
            if (Images != null && Images.Count > 0)
            {
                if (Courrante < 0)
                {
                    //Courrante = ~Courrante;//On montre
                    base.Révéler();
                }
                else if (delta < 0)
                {
                    ++Courrante;
                    if (Courrante >= Images.Count)
                        Courrante = 0;
                }
                else if (delta > 0)
                {
                    --Courrante;
                    if (Courrante < 0)
                        Courrante = Images.Count - 1;
                }
            }
            return true;
        }

        override public ContextMenu Menu(IBoard ctrl, Joueur jr, Element elmRt)
        {
            ContextMenu cm = base.Menu(ctrl, jr, elmRt);
            if (cm == null) cm = new ContextMenu();

            MenuItem nbc = new MenuItem((Images?.Count ?? 0) + " Faces(s)");
            int idx;
            for (idx = 0; idx < cm.MenuItems.Count && cm.MenuItems[idx].Text != "État"; ++idx) ;
            if (idx < cm.MenuItems.Count) cm.MenuItems[idx].MenuItems.Add(0, nbc);
            else cm.MenuItems.Add(new MenuItem("État", new MenuItem[1] { nbc }));

            cm.MenuItems.AddRange(new MenuItem[]
                    {
                        new MenuItem("Mélanger", new EventHandler((o,e) => { ctrl.Mélanger(jr, elmRt, this);/*Mélanger(); ctrl.Refresh();*/ }))
                    });
            return cm;
        }

        public override bool Lier(XmlNode paq, Dictionary<string, Element> dElements)
        {
            return true;
        }

        public override bool PutOnTop(Element elm)
        {
            return (this == elm);
        }

        private void VérifierCourrante()
        {
            if (Images != null && Images.Any())
            {
                if (Courrante < 0)
                {
                    if (Courrante < -Images.Count) Courrante = -Images.Count;
                }
                else
                {
                    if (Courrante >= Images.Count) Courrante = Images.Count - 1;
                }
            }
        }

        public void Mélanger(Random rnd = null)
        {
            if (Images != null && Images.Any())
            {
                if (rnd == null) rnd = new Random();
                Courrante = rnd.Next(Images.Count);
            }
        }

        public Dés(Stream stream, IRessourcesDésérialiseur resscDes)
            : base(stream, resscDes)
        {
            Courrante = stream.ReadInt();
            ushort nbc = BitConverter.ToUInt16(stream.GetBytes(2), 0);
            if (nbc > 0)
            {
                Images = new List<Graphique>(nbc);
                for (ushort i = 0; i < nbc; ++i)
                    Images.Add(resscDes.RécupérerGraphique(stream));
            }
            else Images = null;
        }

        override public void Serialiser(Stream stream, ref int gidr)
        {
            base.Serialiser(stream, ref gidr);
            stream.WriteBytes(BitConverter.GetBytes(Courrante));
            ushort nbc = (ushort)(Images?.Count ?? 0);
            stream.WriteBytes(BitConverter.GetBytes(nbc));
            for (ushort i = 0; i < nbc; ++i)
            {
                Graphique.Serialiser(Images[i], stream);
            }
        }
    }
}
